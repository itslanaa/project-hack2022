<!--sidebar-->
<aside class="sidebar">
	<?php dynamic_sidebar( 'default-sidebar' ); ?>
</aside>
<!--sidebar ends-->