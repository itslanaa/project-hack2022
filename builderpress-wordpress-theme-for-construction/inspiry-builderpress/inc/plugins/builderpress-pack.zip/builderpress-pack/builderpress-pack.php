<?php
/**
 * Plugin Name:        BuilderPress Pack
 * Description:        This plugin provides plugin territory functionaity for BuilderPress theme.
 * Version:            1.1.2
 * Author:            Inspiry Themes
 * Author URI:        https://inspirythemes.com/
 * Text Domain:        builderpress-pack
 * Domain Path:        /languages
 */

/*
 *  Make sure the plugin is accessed through the appropriate channels
 */
defined( 'ABSPATH' ) || die;

define( 'BPP_VERSION', '1.1.2' );
define( 'BPP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'BPP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'BPP_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

function builderpress_pack_load_textdomain() {
	load_plugin_textdomain( 'builderpress-pack', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
}

add_action( 'plugins_loaded', 'builderpress_pack_load_textdomain' );

function builderpress_pack_menu() {

	add_menu_page(
		esc_html__( 'BuilderPress', 'builderpress-pack' ),
		esc_html__( 'BuilderPress', 'builderpress-pack' ),
		'edit_posts',
		'builderpress-pack',
		'',
		'dashicons-admin-tools',
		'5'
	);

	// Add sub menus
	$sub_menus = [];

	$sub_menus['addnewproject'] = array(
		'builderpress-pack',
		esc_html__( 'Projects', 'builderpress-pack' ),
		esc_html__( 'Projects', 'builderpress-pack' ),
		'edit_posts',
		'edit.php?post_type=project',
	);

	$sub_menus['projectcategory'] = array(
		'builderpress-pack',
		esc_html__( 'Project Categories', 'builderpress-pack' ),
		esc_html__( 'Project Categories', 'builderpress-pack' ),
		'edit_posts',
		'edit-tags.php?taxonomy=project-category&post_type=project',
	);

	$sub_menus['teammember'] = array(
		'builderpress-pack',
		esc_html__( 'Team', 'builderpress-pack' ),
		esc_html__( 'Team', 'builderpress-pack' ),
		'edit_posts',
		'edit.php?post_type=members',
	);

	$sub_menus['bpp_settings'] = array(
		'builderpress-pack',
		esc_html__( 'Settings', 'builderpress-pack' ),
		esc_html__( 'Settings', 'builderpress-pack' ),
		'manage_options',
		'bpp-settings',
		'builderpress_pack_settings_page'
	);

	// Filter $_SERVER array.
	$server_array            = filter_input_array( INPUT_SERVER );
	$customize_settings_slug = 'customize.php';
	if ( isset( $server_array['REQUEST_URI'] ) ) {
		$customize_settings_slug = add_query_arg( 'return', rawurlencode( remove_query_arg( wp_removable_query_args(), wp_unslash( $server_array['REQUEST_URI'] ) ) ), 'customize.php' );
	}

	$sub_menus['settings'] = array(
		'builderpress-pack',
		esc_html__( 'Customize', 'builderpress-pack' ),
		esc_html__( 'Customize', 'builderpress-pack' ),
		'manage_options',
		$customize_settings_slug,
	);

	if ( class_exists( 'OCDI_Plugin' ) ) {
		$sub_menus['demoimport'] = array(
			'builderpress-pack',
			esc_html__( 'Demo Import', 'builderpress-pack' ),
			esc_html__( 'Demo Import', 'builderpress-pack' ),
			'import',
			'admin.php?page=one-click-demo-import',
		);
	}

	if ( $sub_menus ) {
		foreach ( $sub_menus as $sub_menu ) {
			call_user_func_array( 'add_submenu_page', $sub_menu );
		}
	}
}

add_action( 'admin_menu', 'builderpress_pack_menu' );

function builderpress_pack_expand_menu() {

	$screen    = get_current_screen();
	$menu_list = array(
		'edit-project-category',
		'admin_page_one-click-demo-import'
	);
	$menu_arr  = apply_filters( 'builderpress_open_menus_slugs', $menu_list );

	// Check if the current screen's ID has any of the above menu array items.
	if ( isset( $screen->id ) && in_array( $screen->id, $menu_arr ) ) {

		// Filter $_GET array for security.
		$get_array    = filter_input_array( INPUT_GET );
		$current_menu = '';

		if ( isset( $get_array['taxonomy'] ) && ( 'project-category' === $get_array['taxonomy'] ) ) {
			$current_menu = 'taxonomy=project-category';
		}

		if ( isset( $get_array['page'] ) && ( 'one-click-demo-import' === $get_array['page'] ) ) {
			$current_menu = 'page=one-click-demo-import';
		}

		if ( ! empty( $current_menu ) ) {

			$data = "
		    function builderpress_pack_expand_menu(currentMenu){
		        $ = jQuery;
                $(document).ready(function () {
                    $('body').removeClass('sticky-menu');
                    $('#toplevel_page_builderpress-pack').addClass('wp-has-current-submenu wp-menu-open').removeClass('wp-not-current-submenu');
                    $('#toplevel_page_builderpress-pack > a').addClass('wp-has-current-submenu wp-menu-open').removeClass('wp-not-current-submenu');
                    if (currentMenu) {
                        const anchors = $('#toplevel_page_builderpress-pack ul').find('li').children('a');
                        anchors.each(function () {
                            if (this.href.indexOf(currentMenu) >= 0) {
                                $(this).parent('li').addClass('current');
                            }
                        });
                    }
                });
             }
            ";
			$data .= 'builderpress_pack_expand_menu("' . esc_html( $current_menu ) . '")';

			return $data;
		}
	}
}

function builderpress_pack_show_menu( $show_in_menu ) {
	return 'builderpress-pack';
}

add_filter( 'bpp_service_show_in_menu', 'builderpress_pack_show_menu' );

function builderpress_pack_hide_menu( $show_in_menu ) {
	return false;
}

add_filter( 'bpp_project_show_in_menu', 'builderpress_pack_hide_menu' );
add_filter( 'bpp_team_show_in_menu', 'builderpress_pack_hide_menu' );

function builderpress_pack_tabs() {

	$tabs = array(
		'social'   => esc_html__( 'Social Navigation', 'builderpress-pack' ),
		'tracking' => esc_html__( 'Tracking Code', 'builderpress-pack' ),
		'map'      => esc_html__( 'Maps', 'builderpress-pack' ),
	);

	return $tabs;
}

function builderpress_pack_tabs_nav( $current_tab ) {

	$tabs = builderpress_pack_tabs();
	?>
    <div id="inspiry-bpp-tabs" class="inspiry-bpp-tabs">
		<?php
		if ( ! empty( $tabs ) && is_array( $tabs ) ) {
			foreach ( $tabs as $slug => $title ) {
				if ( file_exists( BPP_PLUGIN_DIR . 'inc/settings/' . $slug . '.php' ) ) {
					$active_tab = ( $current_tab === $slug ) ? ' inspiry-is-active-tab' : '';
					$admin_url  = ( $current_tab === $slug ) ? '#' : admin_url( 'admin.php?page=bpp-settings&tab=' . $slug );
					echo '<a class="inspiry-bpp-tab ' . esc_attr( $active_tab ) . '" href="' . esc_url_raw( $admin_url ) . '" data-tab="' . esc_attr( $slug ) . '">' . esc_html( $title ) . '</a>';
				}
			}
		}
		?>
    </div>
	<?php
}

function builderpress_pack_settings_page() {
	require_once BPP_PLUGIN_DIR . 'inc/settings/settings.php';
}

function builderpress_pack_option( $value, $default = false, $type = 'text' ) {

	$option = get_option( $value, $default );

	if ( isset( $_POST[ $value ] ) ) {

		$value = $_POST[ $value ];

		switch ( $type ) {
			case 'textarea':
				$allowed_html = array(
					'script' => array(
						'id'    => array(),
						'class' => array(),
						'async' => array(),
						'type'  => array(),
						'src'   => array()
					),
					'style'  => array(
						'id'    => array(),
						'class' => array(),
						'type'  => array(),
					)
				);
				$value        = wp_kses( $value, $allowed_html );
				break;

			default:
				$value = sanitize_text_field( $value );
		}

		return $value;
	}

	return $option;
}

function builderpress_pack_admin_styles() {
	wp_enqueue_style( 'builderpress-pack', BPP_PLUGIN_URL . 'css/admin.css', array(), BPP_VERSION, 'all' );
}
add_action( 'admin_enqueue_scripts', 'builderpress_pack_admin_styles' );

function builderpress_pack_admin_scripts() {
	wp_enqueue_script( 'builderpress-pack-js', BPP_PLUGIN_URL . 'js/inspiry-plugin.js', array( 'jquery' ), BPP_VERSION, true );
	wp_add_inline_script( 'builderpress-pack-js', builderpress_pack_expand_menu() );
}
add_action( 'admin_enqueue_scripts', 'builderpress_pack_admin_scripts' );

function builderpress_pack_scripts() {

	// Google Map API
	$google_maps_api_key = get_option( 'inspiry_google_maps_api_key' );
	if ( ! empty( $google_maps_api_key ) ) {
		wp_register_script( 'google-map-api-key', '//maps.google.com/maps/api/js?key=' . esc_attr( $google_maps_api_key ), array(), '', true );
		wp_register_script( 'builderpress-google-map', BPP_PLUGIN_URL . 'js/inspiry-google-map.js', array(
			'jquery',
			'google-map-api-key'
		), '1.1.2', true );
	}
}
add_action( 'wp_enqueue_scripts', 'builderpress_pack_scripts' );


/*-----------------------------------------------------------------------------------*/
/*	User Social Profile To Contact Info
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'inspiry_user_social_profiles' ) ) :
	/**
	 * Adds user social profiles to contact info.
	 *
	 * @since 1.0.0
	 *
	 * @param array $user_contact
	 *
	 * @return array Array of contact methods with theme additions.
	 */
	function inspiry_user_social_profiles( $user_contact ) {
		$user_contact['inspiry_facebook_url']  = esc_html__( 'Facebook URL', 'builderpress-pack' );
		$user_contact['inspiry_twitter_url']   = esc_html__( 'Twitter URL', 'builderpress-pack' );
		$user_contact['inspiry_instagram_url'] = esc_html__( 'Instagram URL', 'builderpress-pack' );
		$user_contact['inspiry_youtube_url']   = esc_html__( 'Youtube URL', 'builderpress-pack' );

		return $user_contact;
	}

	add_filter( 'user_contactmethods', 'inspiry_user_social_profiles' );
endif;

if ( ! function_exists( 'inspiry_render_user_social_icons' ) ) :
	/**
	 * Author Social Profile
	 */
	function inspiry_render_user_social_icons() {

	    global $post;

		$inspiry_user_link_facebook  = get_the_author_meta( 'inspiry_facebook_url', $post->post_author );
		$inspiry_user_link_twitter   = get_the_author_meta( 'inspiry_twitter_url', $post->post_author );
		$inspiry_user_link_instagram = get_the_author_meta( 'inspiry_instagram_url', $post->post_author );
		$inspiry_user_link_youtube   = get_the_author_meta( 'inspiry_youtube_url', $post->post_author );

		if ( ! empty( $inspiry_user_link_twitter ) ||
		     ! empty( $inspiry_user_link_facebook ) ||
		     ! empty( $inspiry_user_link_youtube ) ||
		     ! empty( $inspiry_user_link_instagram )
		) {
			?>
            <ul>
				<?php
				if ( ! empty( $inspiry_user_link_facebook ) ) {
					?>
                    <li>
                        <a target="_blank"
                           href="<?php echo esc_url( $inspiry_user_link_facebook ); ?>"><i
                                    class="fa fa-facebook-square"></i></a>
                    </li>
					<?php
				}
                
				if ( ! empty( $inspiry_user_link_twitter ) ) {
					?>
                    <li>
                        <a target="_blank"
                           href="<?php echo esc_url( $inspiry_user_link_twitter ); ?>"><i
                                    class="fa fa-twitter"></i></a>
                    </li>
					<?php
				}

				if ( ! empty( $inspiry_user_link_instagram ) ) {
					?>
                    <li>
                        <a target="_blank"
                           href="<?php echo esc_url( $inspiry_user_link_instagram ); ?>"><i
                                    class="fa fa-instagram"></i></a>
                    </li>
					<?php
				}

				if ( ! empty( $inspiry_user_link_youtube ) ) {
					?>
                    <li>
                        <a target="_blank"
                           href="<?php echo esc_url( $inspiry_user_link_youtube ); ?>"><i
                                    class="fa fa-youtube-play"></i></a>
                    </li>
					<?php
				}
				?>
            </ul>
			<?php
		}
	}
endif;

if ( ! function_exists( 'inspiry_render_footer_social_icons' ) ) :
	/**
	 * User Social Profile To Contact Info
	 *
	 * @param string $enable_social_links Enable social links.
	 */
	function inspiry_render_footer_social_icons( $enable_social_links ) {

		if ( 'true' === $enable_social_links ) {

			$twitter_link   = get_option( 'twitter_link' );
			$facebook_link  = get_option( 'facebook_link' );
			$youtube_link   = get_option( 'youtube_link' );
			$instagram_link = get_option( 'instagram_link' );
			$linkedin_link  = get_option( 'linkedin_link' );
			?>
            <ul class="top-social-nav">
				<?php
				if ( ! empty( $facebook_link ) ) {
					?>
                    <li><a href="<?php echo esc_url( $facebook_link ); ?>"><i class="fa fa-facebook-square"></i></a>
                    </li>
					<?php
				}
				if ( ! empty( $twitter_link ) ) {
					?>
                    <li><a href="<?php echo esc_url( $twitter_link ); ?>"><i class="fa fa-twitter"></i></a></li>
					<?php
				}
				if ( ! empty( $youtube_link ) ) {
					?>
                    <li><a href="<?php echo esc_url( $youtube_link ); ?>"><i class="fa fa-youtube-play"></i></a>
                    </li>
					<?php
				}
				if ( ! empty( $instagram_link ) ) {
					?>
                    <li><a href="<?php echo esc_url( $instagram_link ); ?>"><i class="fa fa-instagram"></i></a></li>
					<?php
				}
				if ( ! empty( $linkedin_link ) ) {
					?>
                    <li><a href="<?php echo esc_url( $linkedin_link ); ?>"><i class="fa fa-linkedin"></i></a></li>
					<?php
				}
				?>
            </ul>
			<?php
		}
	}
endif;

/*-----------------------------------------------------------------------------------*/
/*	BP Post Types
/*-----------------------------------------------------------------------------------*/
include_once( BPP_PLUGIN_DIR . 'admin/bp-post-types.php' );

/*-----------------------------------------------------------------------------------*/
/*  Include Meta Boxes
/*-----------------------------------------------------------------------------------*/
include_once( BPP_PLUGIN_DIR . 'admin/bp-meta-box.php' );

/*-----------------------------------------------------------------------------------*/
/*	Shortcodes
/*-----------------------------------------------------------------------------------*/
include_once( BPP_PLUGIN_DIR . 'inc/vc-elements/inspiry-vc-functions.php' );
include_once( BPP_PLUGIN_DIR . 'inc/shortcodes/shortcodes.php' );

/*-----------------------------------------------------------------------------------*/
/*	widgets
/*-----------------------------------------------------------------------------------*/
include_once( BPP_PLUGIN_DIR . 'widgets/recent-posts-with-thumbnail.php' );
include_once( BPP_PLUGIN_DIR . 'widgets/builderpress-services.php' );
include_once( BPP_PLUGIN_DIR . 'widgets/contact-list.php' );

if ( ! function_exists( 'register_theme_widgets' ) ) {
	/**
	 * Register custom widgets
	 */
	function register_theme_widgets() {
		register_widget( 'inspiry_recent_posts_with_thumbnails' );
		register_widget( 'inspiry_builderpress_services' );
		register_widget( 'inspiry_contact_list' );
	}

	add_action( 'widgets_init', 'register_theme_widgets' );
}