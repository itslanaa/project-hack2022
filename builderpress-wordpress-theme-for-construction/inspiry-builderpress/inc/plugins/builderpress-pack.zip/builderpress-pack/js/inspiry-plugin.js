/*-----------------------------------------------------------------------------------*/
/*	Admin side JS
 /*-----------------------------------------------------------------------------------*/
(function($){

    "use strict";

    $(document).ready(function() {


        /*-----------------------------------------------------------------------------------*/
        /*	To Control Metaboxes on pages
         /*-----------------------------------------------------------------------------------*/
        var page_meta_box = $('#bp-page-meta');
        var page_lay_meta = $('.inspiry-page-layout');
        var selectedOption = $('#page_template option:selected');
        var projectTemplate = 'page-templates/template-projects.php';
        var serviceTemplate = 'page-templates/template-services.php';

        var group = $('#page_template');
        $(page_meta_box).hide();
        $(page_lay_meta).hide();
        if( selectedOption.val() == projectTemplate ||
            selectedOption.val() == serviceTemplate )
        {
            page_meta_box.show();
        }
        if(selectedOption.val() == projectTemplate){
            page_lay_meta.show();
        }


        group.change( function() {
            var newValue = $(this).val();

            if(newValue == projectTemplate || newValue == serviceTemplate)
            {
                page_meta_box.show();
            }else{
                page_meta_box.hide();
            }
            if(newValue == projectTemplate){
                page_lay_meta.show();
            }else {
                page_lay_meta.hide();
            }


        });


    });



})(jQuery);