<?php
function bpp_load_vc_shortcodes(){
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/section-icon.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/section-heading-intro.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/cta-bar.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/carousel-clients.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/team.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/testimonials.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/testimonials-var2.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/recent-posts.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/portfolio.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/featured-projects.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/google-map.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/contact-form.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/contact-details.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/featured-projects-var2.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/services.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/services-var2.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/expertise-var1.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/expertise-var2.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/why-choose-us.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/main-slider-home.php' );
	require_once( BPP_PLUGIN_DIR . 'inc/vc-elements/elements/carousel-core-values.php' );
}
add_action('vc_plugins_loaded','bpp_load_vc_shortcodes');