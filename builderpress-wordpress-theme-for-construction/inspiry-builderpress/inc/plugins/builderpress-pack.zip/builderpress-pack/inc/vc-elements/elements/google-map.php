<?php
/*-----------------------------------------------------------------------------------*/
/*	google map shortcodes
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'inspiry_google_map_shortcodes' ) ) {

	function inspiry_google_map_shortcodes( $atts, $content = null ) {

		$atts = shortcode_atts( array(
			"inspiry_class" => '',
			"map_height"    => 600,
			"map_latitude"  => '',
			"map_longitude" => '',
			"map_zoom"      => 14,
			"map_marker"    => '',
			"info_window"   => '',
		), $atts );

		$google_maps_api_key = get_option( 'inspiry_google_maps_api_key');
		$map_lati  = get_option( 'inspiry_google_maps_lati' );
		$map_longi = get_option( 'inspiry_google_maps_longi' );

		$map_marker = get_template_directory_uri() . '/images/icons/marker.png';
		$map_marker_vc = $atts['map_marker'];

		if ( ! empty( $map_marker_vc ) ) {
			$map_marker = esc_url( wp_get_attachment_url( $map_marker_vc ) );
		}

		$map_height   = esc_html( $atts['map_height'] );
		$map_lati_vc  = esc_html( $atts['map_latitude'] );
		$map_longi_vc = esc_html( $atts['map_longitude'] );
		$map_zoom_vc  = esc_html( $atts['map_zoom'] );
		$info_window  = esc_html( $atts['info_window'] );

		$google_map_lati  = $map_lati;
		$google_map_longi = $map_longi;

		if ( ! empty( $map_lati_vc ) && ! empty( $map_longi_vc ) ) {
			$google_map_lati  = $map_lati_vc;
			$google_map_longi = $map_longi_vc;
		}

		$canvas_id = 'map_canvas_' . str_replace( '.', "", abs( $google_map_lati ) );
		$mapData   = wp_json_encode( array(
			'canvas' => $canvas_id,
			'lati'   => $google_map_lati,
			'longi'  => $google_map_longi,
			'zoom'   => $map_zoom_vc,
			'info'   => $info_window,
			'marker' => $map_marker,
		) );

		ob_start();

		if ( ! empty( $google_maps_api_key ) ) { ?>
            <div id="<?php echo esc_attr( $canvas_id ); ?>"
                 class="common-vc-class <?php echo esc_attr( $atts['inspiry_class'] ); ?>"
                 style="height: <?php echo $map_height; ?>px"></div>
			<?php
			wp_enqueue_script( 'builderpress-google-map' );
			wp_add_inline_script( 'builderpress-google-map', 'builderpress.initializeMap(' . $mapData . ')' );
		} else {
			?>
            <div class="container map-api-alert">
                <p>
					<?php
					$allowed_html = array(
						'strong' => array(),
						'br'     => array(),
						'a'      => array(
							'href'   => array(),
							'target' => array()
						),
					);

					echo wp_kses( __( "Please Enter a Valid Google MAP API Key in <strong>BuilderPress > Settings > Maps > Google Maps API Key</strong>. <br>If you do not have Google Map API Key, <a href='https://developers.google.com/maps/documentation/javascript/get-api-key' target='_blank'>Click Here</a> to get now.", "builderpress-pack" ), $allowed_html ); ?>
                </p>
            </div>
			<?php
		}

		return ob_get_clean();
	}
}
add_shortcode( 'inspiry_google_map', 'inspiry_google_map_shortcodes' );

/*-----------------------------------------------------------------------------------*/
/*	mapper function
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'inspiry_vc_google_map' ) ) {
	function inspiry_vc_google_map() {
		vc_map( array(
				"name"     => esc_html__( "Google Map", "builderpress-pack" ),
				"base"     => "inspiry_google_map",
				"class"    => "",
				"category" => esc_html__( "BuilderPress", "builderpress-pack" ),
				"params"   => array(


					array(
						"type"        => "textfield",
						"heading"     => esc_html__( "Set Height", "builderpress-pack" ),
						"param_name"  => 'map_height',
						"description" => esc_html__( "Default is 600.", "builderpress-pack" )
					),

					array(
						"type"        => "textfield",
						"heading"     => esc_html__( "Latitude", "builderpress-pack" ),
						"param_name"  => 'map_latitude',
						"description" => esc_html__( "Enter map latitude coordinates (If Field is empty, Customizer > Misc > Google Map default Coordinates  will be apply ) .", "builderpress-pack" )
					),

					array(
						"type"        => "textfield",
						"heading"     => esc_html__( "Longitude", "builderpress-pack" ),
						"param_name"  => 'map_longitude',
						"description" => esc_html__( "Enter map longitude coordinates (If Field is empty, Customizer > Misc > Google Map default Coordinates  will be apply) .", "builderpress-pack" )
					),

					array(
						"type"        => "textfield",
						"heading"     => esc_html__( "Address to display in info window", "builderpress-pack" ),
						"param_name"  => 'info_window',
						"description" => esc_html__( "Info window appears by clicking on map marker", "builderpress-pack" )
					),

					array(
						"type"        => "textfield",
						"heading"     => esc_html__( "Map Zoom", "builderpress-pack" ),
						"param_name"  => 'map_zoom',
						"description" => esc_html__( "Defaule value is 14", "builderpress-pack" )
					),

					array(
						"type"        => "attach_image",
						"heading"     => esc_html__( "Select Icon For Google Map Marker ", "builderpress-pack" ),
						"param_name"  => 'map_marker',
						"description" => esc_html__( "Default theme map marker icon will be displayed if no icon selected", "builderpress-pack" )
					),
					array(
						"type"        => "textfield",
						"heading"     => esc_html__( "Extra class name", "builderpress-pack" ),
						"param_name"  => 'inspiry_class',
						"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "builderpress-pack" )
					),


				),

			)
		);
	}
}
add_action( 'vc_before_init', 'inspiry_vc_google_map' );