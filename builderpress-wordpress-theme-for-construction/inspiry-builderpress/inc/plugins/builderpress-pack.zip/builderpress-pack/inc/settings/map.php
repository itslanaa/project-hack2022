<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="inspiry-bpp-page-content">
    <?php
    $inspiry_google_maps_lati    = builderpress_pack_option( 'inspiry_google_maps_lati' );
    $inspiry_google_maps_longi   = builderpress_pack_option( 'inspiry_google_maps_longi' );
    $inspiry_google_maps_api_key = builderpress_pack_option( 'inspiry_google_maps_api_key' );

    if ( isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'inspiry_bpp_settings' ) ) {
	    update_option( 'inspiry_google_maps_lati', $inspiry_google_maps_lati );
	    update_option( 'inspiry_google_maps_longi', $inspiry_google_maps_longi );
	    update_option( 'inspiry_google_maps_api_key', $inspiry_google_maps_api_key );
    }
    ?>
    <form method="post" action="" novalidate="novalidate">
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row"><label for="inspiry_google_maps_lati"><?php esc_html_e( 'Google Maps Latitude', 'builderpress-pack' ); ?></label></th>
                <td><input name="inspiry_google_maps_lati" type="text" id="inspiry_google_maps_lati" value="<?php echo esc_attr( $inspiry_google_maps_lati ); ?>" class="regular-text code"></td>
            </tr>
            <tr>
                <th scope="row"><label for="inspiry_google_maps_longi"><?php esc_html_e( 'Google Maps Longitude', 'builderpress-pack' ); ?></label></th>
                <td><input name="inspiry_google_maps_longi" type="text" id="inspiry_google_maps_longi" value="<?php echo esc_attr( $inspiry_google_maps_longi ); ?>" class="regular-text code"></td>
            </tr>
            <tr>
                <th scope="row"><label for="inspiry_google_maps_api_key"><?php esc_html_e( 'Google Maps API Key', 'builderpress-pack' ); ?></label></th>
                <td>
                    <input name="inspiry_google_maps_api_key" type="text" id="inspiry_google_maps_api_key" value="<?php echo esc_attr( $inspiry_google_maps_api_key ); ?>" class="regular-text code">
                    <p class="description">
                        <?php esc_html_e( 'Enter Google Map Api Key.', 'builderpress-pack' ); ?>
                        <?php echo wp_kses( __( "<a target='_blank' href='https://developers.google.com/maps/documentation/javascript/get-api-key'>Click Here</a> to get Google Map API Key", 'builderpress-pack' ), array( 'a' => array( 'href' => array(), 'target' => array(), ) ) ); ?>
                    </p>
                    <p class="description">
	                    <?php echo wp_kses( __( "<a target='_blank' href='https://inspirythemes.github.io/builderpress-docs/customizer/#google-map-coordinates'>Consult Documentation</a> to learn how to get <strong>Google Map Coordinates</strong> and <strong>Google Map API Key</strong>", 'builderpress-pack' ), array( 'a' => array( 'href' => array(), 'target' => array(), ) ) ); ?>
                    </p>
                </td>
            </tr>
            </tbody>
        </table>
        <div class="submit">
            <?php wp_nonce_field('inspiry_bpp_settings'); ?>
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e( 'Save Changes', 'builderpress-pack' ); ?>">
        </div>
    </form>
</div>