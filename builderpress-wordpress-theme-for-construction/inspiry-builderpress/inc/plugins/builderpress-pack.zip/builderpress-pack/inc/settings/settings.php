<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap">
    <h1 class="screen-reader-text"><?php esc_html_e( 'BuilderPress Pack', 'builderpress-pack' ); ?></h1>
    <div class="inspiry-bpp-page">
        <header class="inspiry-bpp-page-header">
            <h2 class="title"><span class="theme-title"><?php esc_html_e( 'BuilderPress Pack', 'builderpress-pack' ); ?></span></h2>
            <p class="credit">
                <a class="inspiry-bpp-logo-wrap" href="<?php echo esc_url( 'https://inspirythemes.com' ); ?>" target="_blank">
                    <img src="<?php echo BPP_PLUGIN_URL . '/images/logo.png'; ?>" alt=""><?php esc_html_e( 'Inspiry Themes', 'builderpress-pack' ); ?>
                </a>
            </p>
        </header>
		<?php
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'builderpress-pack' ) );
		}

		$current_tab = 'social';
		if ( isset( $_GET['tab'] ) && array_key_exists( $_GET['tab'], builderpress_pack_tabs() ) ) {
			$current_tab = $_GET['tab'];
		}

		builderpress_pack_tabs_nav( $current_tab );

		if( file_exists( BPP_PLUGIN_DIR . 'inc/settings/' . $current_tab . '.php' )){
			require_once BPP_PLUGIN_DIR . 'inc/settings/' . $current_tab . '.php';
        }
		?>
        <footer class="inspiry-bpp-page-footer">
            <p><?php printf( __( 'Version  %s', 'builderpress-pack' ),  BPP_VERSION ); ?></p>
        </footer>
    </div><!-- /.inspiry-bpp-page -->
</div><!-- /.wrap -->
