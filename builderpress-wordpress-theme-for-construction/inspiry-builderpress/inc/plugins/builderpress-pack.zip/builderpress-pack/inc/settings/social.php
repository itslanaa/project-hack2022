<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="inspiry-bpp-page-content">
    <?php
    $enable_top_social_link  = builderpress_pack_option( 'enable_top_social_link', 'true' );
    $enable_footer_social_link = builderpress_pack_option( 'enable_footer_social_link', 'true' );

    $facebook_link     = builderpress_pack_option( 'facebook_link' );
    $twitter_link      = builderpress_pack_option( 'twitter_link' );
    $youtube_link      = builderpress_pack_option( 'youtube_link' );
    $instagram_link    = builderpress_pack_option( 'instagram_link' );
    $linkedin_link     = builderpress_pack_option( 'linkedin_link' );

    if ( isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'inspiry_bpp_settings' ) ) {
        update_option( 'enable_top_social_link', $enable_top_social_link );
        update_option( 'enable_footer_social_link', $enable_footer_social_link );
        update_option( 'facebook_link', $facebook_link );
        update_option( 'twitter_link', $twitter_link );
        update_option( 'linkedin_link', $linkedin_link );
        update_option( 'instagram_link', $instagram_link );
        update_option( 'youtube_link', $youtube_link );
    }
    ?>
    <form method="post" action="" novalidate="novalidate">
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row"><?php esc_html_e( 'Display social links in header?', 'builderpress-pack' ); ?></th>
                <td>
                    <fieldset>
                        <label>
                            <input type="radio" name="enable_top_social_link" value="true" <?php checked( $enable_top_social_link, 'true' ) ?>>
                            <span><?php esc_html_e( 'Yes', 'builderpress-pack' ); ?></span>
                        </label>
                        <br>
                        <label>
                            <input type="radio" name="enable_top_social_link" value="false" <?php checked( $enable_top_social_link, 'false' ) ?>>
                            <span><?php esc_html_e( 'No', 'builderpress-pack' ); ?></span>
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e( 'Display social links in footer?', 'builderpress-pack' ); ?></th>
                <td>
                    <fieldset>
                        <label>
                            <input type="radio" name="enable_footer_social_link" value="true" <?php checked( $enable_footer_social_link, 'true' ) ?>>
                            <span><?php esc_html_e( 'Yes', 'builderpress-pack' ); ?></span>
                        </label>
                        <br>
                        <label>
                            <input type="radio" name="enable_footer_social_link" value="false" <?php checked( $enable_footer_social_link, 'false' ) ?>>
                            <span><?php esc_html_e( 'No', 'builderpress-pack' ); ?></span>
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="facebook_link"><?php esc_html_e( 'Facebook URL', 'builderpress-pack' ); ?></label></th>
                <td><input name="facebook_link" type="url" id="facebook_link" value="<?php echo esc_url( $facebook_link ); ?>" class="regular-text code"></td>
            </tr>
            <tr>
                <th scope="row"><label for="twitter_link"><?php esc_html_e( 'Twitter URL', 'builderpress-pack' ); ?></label></th>
                <td><input name="twitter_link" type="url" id="twitter_link" value="<?php echo esc_url( $twitter_link ); ?>" class="regular-text code"></td>
            </tr>
            <tr>
                <th scope="row"><label for="linkedin_link"><?php esc_html_e( 'Linkedin URL', 'builderpress-pack' ); ?></label></th>
                <td><input name="linkedin_link" type="url" id="linkedin_link" value="<?php echo esc_url( $linkedin_link ); ?>" class="regular-text code"></td>
            </tr>
            <tr>
                <th scope="row"><label for="instagram_link"><?php esc_html_e( 'Instagram URL', 'builderpress-pack' ); ?></label></th>
                <td><input name="instagram_link" type="url" id="instagram_link" value="<?php echo esc_url( $instagram_link ); ?>" class="regular-text code"></td>
            </tr>
            <tr>
                <th scope="row"><label for="youtube_link"><?php esc_html_e( 'YouTube', 'builderpress-pack' ); ?></label></th>
                <td><input name="youtube_link" type="url" id="youtube_link" value="<?php echo esc_url( $youtube_link ); ?>" class="regular-text code"></td>
            </tr>
            </tbody>
        </table>
        <div class="submit">
            <?php wp_nonce_field('inspiry_bpp_settings'); ?>
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e( 'Save Changes', 'builderpress-pack' ); ?>">
        </div>
    </form>
</div>
