<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Expertly
 */

?>

					<?php do_action( 'csco_main_content_end' ); ?>

				</div><!-- .main-content -->

				<?php do_action( 'csco_main_content_after' ); ?>

			</div><!-- .cs-container -->

			<?php do_action( 'csco_site_content_end' ); ?>

		</div><!-- .site-content -->

		<?php do_action( 'csco_site_content_after' ); ?>

		<?php if ( is_active_sidebar( 'sidebar-footer' ) || is_active_sidebar( 'sidebar-footer-2' ) || is_active_sidebar( 'sidebar-footer-3' ) ) { ?>

			<div class="site-footer-widgets">
				<div class="footer-widgets">
					<div class="footer-sidebars">
						<?php if ( is_active_sidebar( 'sidebar-footer' ) ) { ?>
							<div class="sidebar-footer">
								<?php dynamic_sidebar( 'sidebar-footer' ); ?>
							</div>
						<?php } ?>

						<?php if ( is_active_sidebar( 'sidebar-footer-2' ) ) { ?>
							<div class="sidebar-footer">
								<?php dynamic_sidebar( 'sidebar-footer-2' ); ?>
							</div>
						<?php } ?>

						<?php if ( is_active_sidebar( 'sidebar-footer-3' ) ) { ?>
							<div class="sidebar-footer">
								<?php dynamic_sidebar( 'sidebar-footer-3' ); ?>
							</div>
						<?php } ?>

						<?php if ( is_active_sidebar( 'sidebar-footer-4' ) ) { ?>
							<div class="sidebar-footer">
								<?php dynamic_sidebar( 'sidebar-footer-4' ); ?>
							</div>
						<?php } ?>
					</div>
				</div>
			</div><!-- .site-footer-widgets -->

		<?php } ?>

		<?php do_action( 'csco_footer_before' ); ?>

		<?php $scheme = csco_light_or_dark( get_theme_mod( 'color_footer_bg', '#FFFFFF' ), null, 'cs-bg-dark' ); ?>

		<footer id="colophon" class="site-footer <?php echo esc_attr( $scheme ); ?>">

			<div class="site-info">

				<?php
				$social_in_footer = csco_powerkit_module_enabled( 'social_links' ) && get_theme_mod( 'footer_social_links', false );
				if ( $social_in_footer || has_nav_menu( 'footer' ) ) {
					?>
					<div class="footer-aside">
						<?php
						if ( has_nav_menu( 'footer' ) ) {
							wp_nav_menu(
								array(
									'theme_location'  => 'footer',
									'menu_class'      => 'navbar-nav',
									'container'       => 'nav',
									'container_class' => 'navbar-footer',
									'depth'           => 1,
								)
							);
						}

						if ( $social_in_footer ) {
							$scheme  = get_theme_mod( 'footer_social_links_scheme', 'light' );
							$maximum = get_theme_mod( 'footer_social_links_maximum', 5 );

							powerkit_social_links( false, false, true, 'inline', $scheme, 'mixed', $maximum );
						}
						?>
					</div>
				<?php } ?>

				<div class="footer-content">
					<?php
					$footer_title = get_theme_mod( 'footer_title', get_bloginfo( 'desription' ) );
					if ( $footer_title ) {
						?>
						<h5 class="site-title footer-title"><?php echo wp_kses_post( $footer_title ); ?></h5>
						<?php
					}
					?>

					<?php
					/* translators: %s: Author name. */
					$footer_text = get_theme_mod( 'footer_text', sprintf( esc_html__( 'Designed & Developed by %s', 'expertly' ), '<a href="https://codesupply.co/">Code Supply Co.</a>' ) );
					if ( $footer_text ) {
						?>
						<div class="footer-copyright">
							<?php echo do_shortcode( $footer_text ); ?>
						</div>
						<?php
					}
					?>
				</div>

			</div><!-- .site-info -->

		</footer>

		<?php do_action( 'csco_footer_after' ); ?>

	</div><!-- .site-inner -->

	<?php do_action( 'csco_site_end' ); ?>

</div><!-- .site -->

<?php do_action( 'csco_site_after' ); ?>

<?php wp_footer(); ?>
</body>
</html>
