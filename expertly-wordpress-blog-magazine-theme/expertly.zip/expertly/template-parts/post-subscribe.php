<?php
/**
 * The template part for displaying post subscribe section.
 *
 * @package Expertly
 */

$background_image = get_theme_mod( 'post_subscribe_background_image' );
?>

<?php do_action( 'csco_post_subscribe_before' ); ?>

<div class="post-subscribe">
	<?php
		$title = get_theme_mod( 'post_subscribe_title', esc_html__( 'Sign Up for Our Newsletters', 'expertly' ) );
		$text  = get_theme_mod( 'post_subscribe_text', esc_html__( 'Get notified of the best deals on our WordPress themes.', 'expertly' ) );
		$name  = get_theme_mod( 'post_subscribe_name', false );

		echo do_shortcode( sprintf( '[powerkit_subscription_form title="%s" text="%s" bg_image_id="%s" display_name="%s"]', $title, $text, $background_image, $name ) );
	?>
</div>

<?php do_action( 'csco_post_subscribe_after' ); ?>
