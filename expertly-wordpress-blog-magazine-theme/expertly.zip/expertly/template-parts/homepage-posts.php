<?php
/**
 * Template part for displaying homepage posts section.
 *
 * @package Expertly
 */

$ids = csco_get_homepage_posts_ids();

if ( $ids ) {
	$args = array(
		'ignore_sticky_posts' => true,
		'post__in'            => $ids,
		'posts_per_page'      => count( $ids ),
		'post_type'           => array( 'post', 'page' ),
		'orderby'             => 'post__in',
	);

	$the_query = new WP_Query( $args );
}

// Determines whether there are more posts available in the loop.
if ( $ids && $the_query->have_posts() ) {

	do_action( 'csco_homepage_posts_before' );
	?>
	<div class="section-homepage-posts">

		<?php do_action( 'csco_homepage_posts_start' ); ?>

			<div class="cs-container">

				<div class="cs-homepage-posts">
					<?php
					while ( $the_query->have_posts() ) :
						$the_query->the_post();
						?>
						<div class="cs-homepage-post">
							<article <?php post_class(); ?>>
								<?php
								if ( 0 === $the_query->current_post ) {
									?>
									<div class="cs-overlay cs-overlay-ratio cs-ratio-landscape cs-ratio-16by9 cs-bg-dark">
										<div class="cs-overlay-background">
											<?php
											the_post_thumbnail( 'cs-medium', array(
												'class' => 'pk-lazyload-disabled',
											) );
											?>
										</div>
										<div class="cs-overlay-content">
											<?php
											if ( 'post' === get_post_type() ) {
												csco_the_post_format_icon();
												csco_get_post_meta( 'category', false, true, 'home_post_meta' );
											}
											?>
											<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' ); ?>
											<?php
											if ( 'post' === get_post_type() ) {
												csco_get_post_meta( array( 'author', 'date', 'shares', 'views' ), false, true, 'home_post_meta' );
											}
											?>
										</div>
										<a href="<?php the_permalink(); ?>" class="cs-overlay-link"></a>
									</div>
									<?php
								} else {
									?>
									<div class="cs-overlay cs-overlay-hover cs-overlay-ratio cs-ratio-landscape cs-bg-dark">
										<div class="cs-overlay-background">
											<?php
												the_post_thumbnail( 'cs-thumbnail', array(
													'class' => 'pk-lazyload-disabled',
												) );
											?>
										</div>
										<div class="cs-overlay-content">
											<?php
											if ( 'post' === get_post_type() ) {
												csco_the_post_format_icon();
												csco_get_post_meta( 'category', false, true, 'home_post_meta' );
												csco_get_post_meta( array( 'views', 'reading_time' ), false, true, 'home_post_meta' );
											}
											?>
										</div>
										<a href="<?php the_permalink(); ?>" class="cs-overlay-link"></a>
									</div>
									<div class="cs-card">
										<h2 class="h5 entry-title">
											<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
										</h2>
										<?php
										if ( 'post' === get_post_type() ) {
											csco_get_post_meta( array( 'date', 'shares' ), false, true, 'home_post_meta' );
										}
										?>
									</div>
									<?php
								}
								?>
							</article>
						</div>
						<?php
					endwhile;
					?>
				</div>

				<?php wp_reset_postdata(); ?>

			</div>

		<?php do_action( 'csco_homepage_posts_end' ); ?>

		</div>

	<?php
	do_action( 'csco_homepage_posts_after' );
}
