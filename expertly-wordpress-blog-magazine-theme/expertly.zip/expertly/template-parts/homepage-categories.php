<?php
/**
 * Template part for displaying categories section
 *
 * @package Expertly
 */

do_action( 'csco_homepage_categories_before' );

$columns    = get_theme_mod( 'featured_categories_columns', '3' );
$first_post = get_theme_mod( 'featured_categories_first_post', true );
?>

<section class="section-homepage-categories">

	<?php do_action( 'csco_homepage_categories_start' ); ?>

	<div class="cs-container">

		<div class="cs-homepage-categories cs-categories-columns-<?php echo esc_html( $columns ); ?>">

			<?php
			$categories = csco_get_categories_posts();

			foreach ( $categories as $data ) {
				?>
				<div class="cs-homepage-category">

					<div class="cs-homepage-category-header">
						<h6 class="h4 cs-homepage-category-title">
							<a href="<?php echo esc_url( get_category_link( $data['category']->term_id ) ); ?>">
								<?php echo esc_html( $data['category']->name ); ?>
							</a>
						</h6>
						<p class="cs-homepage-category-count"><small>
							<?php
							$post_count = csco_total_cat_post_count( $data['category']->term_id );
							/* translators: 1: Singular, 2: Plural. */
							echo esc_html( sprintf( _n( '%s post', '%s posts', $post_count, 'expertly' ), $post_count ), $post_count );
							?>
						</small></p>
					</div>

					<?php
					if ( $data['query']->have_posts() ) {
						while ( $data['query']->have_posts() ) :
							 $data['query']->the_post();
							if ( 0 === $data['query']->current_post && $first_post ) {
								?>
								<article <?php post_class(); ?>>
									<div class="cs-overlay cs-overlay-ratio cs-ratio-landscape cs-bg-dark">
										<div class="cs-overlay-background">
											<?php the_post_thumbnail( 'cs-thumbnail' ); ?>
										</div>
										<div class="cs-overlay-content">
											<?php the_title( '<h3 class="h' . ( intval( $columns ) ) . ' entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' ); ?>
											<?php csco_get_post_meta( array( 'author', 'date', 'views' ), false, true, 'home_post_meta' ); ?>
											<?php csco_the_post_format_icon(); ?>
										</div>
										<a href="<?php the_permalink(); ?>" class="cs-overlay-link"></a>
									</div>
								</article>
								<?php
							} elseif ( 1 === $data['query']->current_post && $first_post ) {
							?>
								<div class="cs-card-sm">
									<div class="cs-card-thumbnail">
										<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'cs-small' ); ?></a>
									</div>
									<div class="cs-card-content">
										<h6 class="entry-title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h6>
										<?php csco_get_post_meta( array( 'date', 'shares' ), false, true, 'home_post_meta' ); ?>
									</div>
								</div>
							<?php
							} else {
								if ( 2 === $data['query']->current_post && $first_post ) {
									?>
									<ul class="cs-list-articles cs-card text-secondary">
								<?php } ?>
								<li>
									<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
								</li>
								<?php
								if ( $data['query']->post_count === $data['query']->current_post && $first_post ) {
									?>
									</ul>
								<?php
								}
							}
						endwhile;
						wp_reset_postdata();
					}
					?>

				</div>
			<?php } ?>
		</div>

	</div>

	<?php do_action( 'csco_homepage_categories_end' ); ?>

</section>

<?php

do_action( 'csco_homepage_categories_after' );
