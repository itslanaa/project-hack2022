<?php
/**
 * Template part for displaying hero section
 *
 * @package Expertly
 */

do_action( 'csco_hero_before' );

$image_attr = array(
	'class' => 'pk-lazyload-disabled',
	'sizes' => '100vw',
);

$class = 'section-hero cs-overlay';

// Add class if background color is dark.
if ( ! csco_hex_is_light( get_theme_mod( 'hero_background_color', '#F8F8F8' ) ) ) {
	$class .= ' cs-bg-dark';
}

// Add class for center alignment.
$class .= ' hero-' . get_theme_mod( 'hero_alignment', 'left' );

// Add class if background image is outside hero content.
if ( get_theme_mod( 'hero_background_image_outside', false ) && 'center' !== get_theme_mod( 'hero_alignment', 'left' ) ) {
	$image_attr['sizes'] = '(max-width: 1019px) 100vw, 50vw';

	$class .= ' hero-image-outside';
}

?>

<section class="<?php echo esc_attr( $class ); ?>">

	<?php

	do_action( 'csco_hero_start' );

	if ( get_theme_mod( 'hero_background_image' ) ) {
		?>
		<div class="cs-overlay-background">
			<?php echo wp_get_attachment_image( get_theme_mod( 'hero_background_image' ), 'full', false, $image_attr ); ?>
		</div>
		<?php
	}
	?>

	<div class="cs-overlay-content">

		<div class="cs-container">

			<div class="hero-container">

				<div class="hero-content">

					<?php
					$logo_id = get_theme_mod( 'hero_logo' );
					if ( $logo_id ) {
						csco_get_retina_image( $logo_id, array(
							'class' => 'hero-logo',
							'alt'   => get_bloginfo( 'name' ),
						) );
					}
					?>

					<?php
					$title = get_theme_mod( 'hero_title', get_bloginfo( 'name' ) );
					if ( $title ) {
					?>
						<h1 class="hero-title"><?php echo wp_kses( $title, 'post' ); ?></h1>
					<?php } ?>

					<?php
					$lead = get_theme_mod( 'hero_lead', get_bloginfo( 'description' ) );
					if ( $lead ) {
					?>
						<div class="hero-description"><?php echo do_shortcode( $lead ); ?></div>
					<?php } ?>

					<?php
					$hero_search_form       = get_theme_mod( 'hero_search_form', true );
					$hero_subscription_form = get_theme_mod( 'hero_subscription_form', false );

					if ( $hero_search_form || $hero_subscription_form ) {
						$class = $hero_search_form && $hero_subscription_form ? 'hero-forms-two' : null;
					?>
						<div class="hero-forms <?php echo esc_attr( $class ); ?>">
							<?php
							if ( $hero_search_form ) {
								get_search_form();
							}
							?>

							<?php
							if ( $hero_subscription_form ) {
								$name = get_theme_mod( 'hero_subscription_name', false );

								echo do_shortcode( sprintf( '[powerkit_subscription_form display_name="%s"]', $name ) );
							}
							?>
						</div>
					<?php } ?>
				</div>

			</div>

		</div>

	</div>

	<?php do_action( 'csco_hero_end' ); ?>

</section>

<?php

do_action( 'csco_hero_after' );
