<?php
/**
 * The template part for displaying site section.
 *
 * @package Expertly
 */

?>

<div class="site-search" id="search">
	<div class="cs-container">
		<?php get_search_form( true ); ?>
	</div>
</div>
