<?php
/**
 * The template part for displaying post header section.
 *
 * @package Expertly
 */

if ( csco_has_post_meta( 'author' ) ) {
	$author_enabled = true;
} else {
	$author_enabled = false;
}

$authors = array();

if ( csco_coauthors_enabled() && $author_enabled ) {
	$authors = csco_get_coauthors();
}
?>

<div class="post-header">
	<div class="post-header-container">
		<?php
		if ( $authors ) {
			foreach ( $authors as $author ) {
				csco_post_header_avatar( $author->ID );
			}
		} elseif ( $author_enabled ) {
			// Get the default WP author details.
			csco_post_header_avatar( get_the_author_meta( 'ID' ) );
		}
		?>

		<div class="author-details">
			<?php
			if ( $authors ) {
				$social_enabled = count( $authors ) > 1 ? false : true;
				foreach ( $authors as $author ) {
					csco_post_header_author( $author->ID, $social_enabled );
				}
			} elseif ( $author_enabled ) {
				// Get the default WP author details.
				csco_post_header_author( get_the_author_meta( 'ID' ) );
			}
			?>

			<?php csco_get_post_meta( array( 'date', 'reading_time', 'comments' ), false, true, 'post_meta' ); ?>
		</div>
	</div>

	<?php
	if ( is_singular() && csco_powerkit_module_enabled( 'share_buttons' ) ) {
		powerkit_share_buttons_location( 'post_header' );
	}
	?>
</div>
