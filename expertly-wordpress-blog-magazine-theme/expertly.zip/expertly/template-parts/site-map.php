<?php
/**
 * The template part for displaying site map.
 *
 * @package Expertly
 */

?>

<div class="cs-site-map">
	<?php
	if ( ! function_exists( 'cs_walker_site_map' ) ) {
		/**
		 * Output site map.
		 *
		 * @param int   $parent       Category parent ID.
		 * @param array $post__not_in Specify post NOT to retrieve.
		 */
		function cs_walker_site_map( $parent = 0, $post__not_in = array() ) {
			$args = array(
				'taxonomy'        => 'category',
				'hide_empty'      => true,
				'suppress_filter' => true,
				'orderby'         => 'name',
				'order'           => 'ASC',
				'parent'          => $parent,
			);

			$terms = get_terms( $args );

			if ( $parent ) {
				$tag = 'h3';
			} else {
				$tag = 'h2';
			}

			if ( $terms ) {
			?>
				<ul class="cs-categories-list">
					<?php
					// Loop.
					foreach ( $terms as $term ) {
						?>
						<li class="cs-category-item">
							<<?php echo esc_attr( $tag ); ?> class="cs-category-title">
								<a href="<?php echo esc_url( get_category_link( $term->term_id ) ); ?>">
									<?php echo esc_html( $term->name ); ?>
								</a>
							</<?php echo esc_attr( $tag ); ?>>
							<?php
							$args = array(
								'post__not_in'   => $post__not_in,
								'posts_per_page' => -1,
								'tax_query'      => array(
									array(
										'taxonomy'         => 'category',
										'field'            => 'id',
										'terms'            => $term->term_id,
										'include_children' => false,
									),
								),
							);

							$the_query = new WP_Query( $args );

							if ( $the_query->have_posts() ) {
								$articles = array();

								foreach ( $the_query->posts as $object ) {
									$categories = get_the_category( $object->ID );

									$display = true;

									foreach ( $categories as $category ) {
										if ( $term->term_id === $category->category_parent ) {
											$display = false;
										}
									}

									if ( $display ) {
										$articles[] = $object->ID;
									}
								}

								if ( $articles ) {
								?>
								<ul class="cs-list-articles cs-card text-secondary">
									<?php
									foreach ( $articles as $article ) {
										$post__not_in[] = $article;
										?>
											<li>
												<a href="<?php echo esc_attr( get_the_permalink( $article ) ); ?>" title="<?php echo esc_attr( get_the_title( $article ) ); ?>">
													<?php echo esc_html( get_the_title( $article ) ); ?>
												</a>
											</li>
										<?php
									}
									?>
								</ul>
								<?php
								}
							}
							?>

							<?php cs_walker_site_map( $term->term_id, $post__not_in ); ?>
						</li>
						<?php
					}
					?>
				</ul>
			<?php
			}
		}
	}

	// Output.
	cs_walker_site_map();
	?>
</div>
