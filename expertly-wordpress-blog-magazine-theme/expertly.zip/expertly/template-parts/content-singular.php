<?php
/**
 * Template part singular content
 *
 * @package Expertly
 */

$post_type   = get_post_type();
$page_header = csco_get_page_header_type();
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>

	<?php do_action( 'csco_singular_entry_header_before' ); ?>

	<?php if ( 'none' !== $page_header ) { ?>
		<header class="entry-header <?php echo is_singular() ? 'entry-single-header' : null; ?> <?php echo ( 'overlay' === $page_header && is_singular() ) ? ' cs-overlay cs-overlay-no-hover cs-overlay-ratio cs-ratio-landscape cs-ratio-16by9 cs-bg-dark' : ''; ?>">

			<?php do_action( 'csco_singular_entry_header_start' ); ?>

			<?php if ( 'overlay' === $page_header && is_singular() ) { ?>
			<div class="cs-overlay-background">
				<?php
				$image_size = 'cs-medium';
				if ( 'disabled' === csco_get_page_sidebar() ) {
					$image_size = 'cs-large';
				}
				the_post_thumbnail( $image_size, array(
					'class' => 'pk-lazyload-disabled',
				) );
				?>
			</div>
			<div class="cs-overlay-content">
			<?php } ?>

			<?php if ( is_singular( 'post' ) && ( csco_has_post_meta( 'category' ) || csco_has_post_meta( 'views' ) || csco_has_post_meta( 'shares' ) ) ) { ?>
				<div class="entry-inline-meta">
					<?php
					if ( is_singular() ) {
						csco_get_post_meta( 'category', false, true, 'post_meta' );

						csco_get_post_meta( array( 'views', 'shares' ), false, true, 'post_meta' );
					} else {
						// Post Category.
						csco_get_post_meta( 'category', false, true, true );

						// Post Meta.
						csco_get_post_meta( array( 'views', 'shares' ), false, true, true );
					}
					?>
				</div>
			<?php } ?>

			<?php
			if ( is_singular() ) {
				the_title( '<h1 class="entry-title">', '</h1>' );

				if ( 'page' === get_post_type() ) {
					$excerpt_enabled = get_theme_mod( 'page_excerpt', true ) && has_excerpt();
				} else {
					$excerpt_enabled = get_theme_mod( 'post_excerpt', true ) && has_excerpt();
				}

				if ( $excerpt_enabled ) {
					?>
					<div class="post-excerpt"><?php the_excerpt(); ?></div>
					<?php
				}
			} else {
				// Post Title.
				the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
			}

			if ( 'post' === $post_type ) {
				get_template_part( 'template-parts/post-header' );
			}
			?>

			<?php if ( 'overlay' === $page_header && is_singular() ) { ?>
			</div>
			<?php } ?>

			<?php do_action( 'csco_singular_entry_header_end' ); ?>

		</header>
	<?php } ?>

	<?php do_action( 'csco_singular_content_before' ); ?>

	<div class="entry-content-wrap">

		<?php do_action( 'csco_singular_content_start' ); ?>

		<div class="entry-content">

			<?php
			if ( ! is_singular() && 'excerpt' === get_theme_mod( csco_get_archive_option( 'summary' ), 'excerpt' ) ) {
				the_excerpt();

				if ( get_theme_mod( csco_get_archive_option( 'more_button' ), true ) ) {
					?>
					<div class="entry-more-button">
						<a class="button entry-more" href="<?php echo esc_url( get_permalink() ); ?>">
							<?php echo esc_html( get_theme_mod( 'label_readmore', __( 'View Post', 'expertly' ) ) ); ?>
						</a>
					</div><!-- .entry-more-button -->
					<?php
				}
			} else {
				$more_link_text = false;

				if ( get_theme_mod( csco_get_archive_option( 'more_button' ), true ) ) {
					$more_link_text = sprintf(
						/* translators: %s: Name of current post */
						__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'expertly' ),
						get_the_title()
					);
				}

				the_content( $more_link_text );
			}
			?>

		</div>
		<?php do_action( 'csco_singular_content_end' ); ?>
	</div>

	<?php do_action( 'csco_singular_content_after' ); ?>

</article>
