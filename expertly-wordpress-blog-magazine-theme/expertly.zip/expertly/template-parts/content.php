<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Expertly
 */

global $wp_query;

$post_type = get_post_type();

// Var Archive type.
if ( get_query_var( 'csco_archive_layout' ) ) {
	$archive_layout = get_theme_mod( get_query_var( 'csco_archive_layout' ), 'grid' );
} else {
	$archive_layout = get_theme_mod( csco_get_archive_option( 'layout' ), 'grid' );
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="post-outer">

		<?php
		$orientation = 'cs-overlay-ratio cs-ratio-landscape';
		$image_size  = 'cs-thumbnail';

		if ( in_array( $archive_layout, array( 'masonry', 'full-masonry' ), true ) ) {
			$image_size  = 'cs-thumbnail-uncropped';
			$orientation = null;
		}

		if ( in_array( $archive_layout, array( 'list', 'full-list' ), true ) && 'disabled' === csco_get_page_sidebar() ) {
			$image_size = 'cs-medium';
		}
		?>

		<?php if ( has_post_thumbnail() ) { ?>
		<div class="post-inner">
			<div class="entry-thumbnail">
				<div class="cs-overlay cs-overlay-hover  cs-bg-dark <?php echo esc_attr( $orientation ); ?>">
					<div class="cs-overlay-background">
						<?php the_post_thumbnail( $image_size ); ?>
					</div>
					<?php if ( 'post' === $post_type ) { ?>
					<div class="cs-overlay-content">
						<?php csco_get_post_meta( 'category', false, true, true ); ?>
						<?php csco_get_post_meta( array( 'views', 'reading_time', 'comments' ), false, true, true ); ?>
						<?php csco_the_post_format_icon(); ?>
					</div>
					<?php } ?>
					<a href="<?php the_permalink(); ?>" class="cs-overlay-link"></a>
				</div>
			</div>
		</div>
		<?php } ?>

		<div class="post-inner">
			<header class="entry-header">
				<?php

				// Post Title.
				the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );

				// Post Meta.
				if ( 'post' === $post_type ) {
					csco_get_post_meta( array( 'author', 'date', 'shares' ), false, true, true );
				}
				?>
			</header><!-- .entry-header -->

			<div class="entry-excerpt">
				<?php
				the_excerpt();
				?>
			</div><!-- .entry-excerpt -->

			<div class="entry-details">
				<?php
				if ( get_theme_mod( csco_get_archive_option( 'more_button' ), true ) ) {
					?>
					<div class="entry-more">
						<a class="cs-link-more" href="<?php echo esc_url( get_permalink() ); ?>">
							<?php echo esc_html( get_theme_mod( 'label_readmore', __( 'View Post', 'expertly' ) ) ); ?>
						</a>
					</div><!-- .entry-more-button -->
					<?php
				}
				?>
			</div>

		</div><!-- .post-inner -->

	</div><!-- .post-outer -->
</article><!-- #post-<?php the_ID(); ?> -->
