<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package Expertly
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<?php do_action( 'csco_site_before' ); ?>

<div id="page" class="site">

	<?php do_action( 'csco_site_start' ); ?>

	<div class="site-inner">

		<?php do_action( 'csco_header_before' ); ?>

		<header id="masthead" class="site-header">

			<?php do_action( 'csco_header_start' ); ?>

			<?php $scheme = csco_light_or_dark( get_theme_mod( 'color_navbar_bg', '#FFFFFF' ), null, ' cs-bg-dark' ); ?>

			<nav class="navbar navbar-primary<?php echo esc_attr( $scheme ); ?>">

				<?php do_action( 'csco_navbar_start' ); ?>

				<div class="navbar-wrap">

					<div class="navbar-container">

						<div class="navbar-content">

							<?php do_action( 'csco_navbar_content_start' ); ?>

							<?php if ( csco_offcanvas_exists() ) { ?>
								<button type="button" class="toggle-offcanvas">
									<i class="cs-icon cs-icon-menu"></i>
								</button>
							<?php } ?>

							<?php
							$logo_id = get_theme_mod( 'logo' );

							if ( $logo_id ) {
								?>
								<a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
									<?php csco_get_retina_image( $logo_id, array( 'alt' => get_bloginfo( 'name' ) ) ); ?>
								</a>
								<?php
							} else {
								?>
								<a class="navbar-brand site-title" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
								<?php
							}
							$description = get_bloginfo( 'description' );
							if ( $description && get_theme_mod( 'navbar_site_description', true ) ) {
								?>
								<p class="navbar-text site-description"><?php echo wp_kses( $description, 'post' ); ?></p>
								<?php
							}
							?>

							<?php
							if ( has_nav_menu( 'primary' ) ) {
								wp_nav_menu( array(
									'theme_location'  => 'primary',
									'menu_class'      => 'navbar-nav',
									'container'       => '',
									'container_class' => '',
								) );
							}
							?>

							<?php do_action( 'csco_navbar_content_end' ); ?>

						</div><!-- .navbar-content -->

					</div><!-- .navbar-container -->

				</div><!-- .navbar-wrap -->

				<?php do_action( 'csco_navbar_end' ); ?>

			</nav><!-- .navbar -->

			<?php do_action( 'csco_header_end' ); ?>

		</header><!-- #masthead -->

		<?php do_action( 'csco_header_after' ); ?>

		<?php do_action( 'csco_site_content_before' ); ?>

		<div class="site-content">

			<?php do_action( 'csco_site_content_start' ); ?>

			<div class="cs-container">

				<?php do_action( 'csco_main_content_before' ); ?>

				<div id="content" class="main-content">

					<?php do_action( 'csco_main_content_start' ); ?>
