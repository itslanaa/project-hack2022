<?php
/**
 * Powerkit Filters
 *
 * @package Expertly
 */

if ( ! function_exists( 'csco_share_buttons_post_meta' ) ) {
	/**
	 * Register Post Archive Share Buttons Location
	 *
	 * @param array $locations List of Locations.
	 */
	function csco_share_buttons_post_meta( $locations = array() ) {

		$locations['post_meta'] = array(
			'shares'         => array( 'facebook', 'twitter', 'pinterest' ),
			'name'           => esc_html__( 'Post Meta', 'expertly' ),
			'location'       => 'post_meta',
			'mode'           => 'cached',
			'before'         => '',
			'after'          => '',
			'display'        => true,
			'meta'           => array(
				'icons'  => true,
				'titles' => false,
				'labels' => false,
			),
			// Display only the specified layouts and color schemes.
			'fields'         => array(
				'layouts'         => array( 'simple' ),
				'schemes'         => array( 'default', 'bold' ),
				'count_locations' => array( 'inside' ),
			),
			'display_total'  => false,
			'layout'         => 'simple',
			'scheme'         => 'bold',
			'count_location' => 'inside',
		);

		return $locations;
	}
}
add_filter( 'powerkit_share_buttons_locations', 'csco_share_buttons_post_meta' );

if ( ! function_exists( 'csco_share_buttons_post_header' ) ) {
	/**
	 * Register Post Header Share Buttons Location
	 *
	 * @param array $locations List of Locations.
	 */
	function csco_share_buttons_post_header( $locations = array() ) {

		$locations['post_header'] = array(
			'shares'         => array( 'facebook', 'twitter', 'pinterest' ),
			'name'           => esc_html__( 'Post Header', 'expertly' ),
			'location'       => 'post_header',
			'mode'           => 'mixed',
			'before'         => '',
			'after'          => '',
			'display'        => true,
			'meta'           => array(
				'icons'  => true,
				'titles' => false,
				'labels' => true,
			),
			// Display only the specified layouts and color schemes.
			'fields'         => array(
				'display_total'   => true,
				'display_count'   => true,
				'layouts'         => array( 'default' ),
				'schemes'         => array( 'default', 'bold', 'bold-bg' ),
				'count_locations' => array( 'inside' ),
			),
			'layout'         => 'default',
			'scheme'         => 'bold-bg',
			'count_location' => 'inside',
		);

		return $locations;
	}
}
add_filter( 'powerkit_share_buttons_locations', 'csco_share_buttons_post_header' );

if ( ! function_exists( 'csco_share_buttons_post_sidebar' ) ) {
	/**
	 * Register Floated Share Buttons Location
	 *
	 * @param array $locations List of Locations.
	 */
	function csco_share_buttons_post_sidebar( $locations = array() ) {

		$locations['post_sidebar'] = array(
			'shares'         => array( 'facebook', 'twitter', 'pinterest', 'mail' ),
			'name'           => esc_html__( 'Entry Sidebar', 'expertly' ),
			'location'       => 'post_sidebar',
			'mode'           => 'mixed',
			'before'         => '',
			'after'          => '',
			'display'        => true,
			'meta'           => array(
				'icons'  => true,
				'titles' => false,
				'labels' => false,
			),
			// Display only the specified layouts and color schemes.
			'fields'         => array(
				'display_total'   => true,
				'display_count'   => true,
				'layouts'         => array( 'simple' ),
				'schemes'         => array( 'default', 'bold', 'bold-bg' ),
				'count_locations' => array( 'outside' ),
			),
			'layout'         => 'simple',
			'scheme'         => 'bold-bg',
			'count_location' => 'outside',
		);

		unset( $locations['before-content'] );

		return $locations;
	}
}
add_filter( 'powerkit_share_buttons_locations', 'csco_share_buttons_post_sidebar' );

if ( ! function_exists( 'csco_powerkit_widget_author_image_size' ) ) {
	/**
	 * Register Floated Share Buttons Location
	 */
	function csco_powerkit_widget_author_image_size() {
		return 'cs-thumbnail-uncropped';
	}
}
add_filter( 'powerkit_widget_author_image_size', 'csco_powerkit_widget_author_image_size' );

if ( ! function_exists( 'csco_powerkit_widget_contributors_description_length' ) ) {
	/**
	 * Change Contributors widget post author description length.
	 */
	function csco_powerkit_widget_contributors_description_length() {
		return 80;
	}
}
add_filter( 'powerkit_widget_contributors_description_length', 'csco_powerkit_widget_contributors_description_length' );

if ( ! function_exists( 'csco_powerkit_lightbox_image_selector' ) ) {
	/**
	 * Add new image selector for Lightbox
	 *
	 * @param string $selectors List selectors.
	 */
	function csco_powerkit_lightbox_image_selector( $selectors ) {
		$selectors[] = '.single .post-media img';

		return $selectors;
	}
}
add_filter( 'powerkit_lightbox_image_selectors', 'csco_powerkit_lightbox_image_selector' );

if ( ! function_exists( 'csco_related_posts_args' ) ) {
	/**
	 * Exclude Inline Posts posts from related posts block
	 *
	 * @param array $args Array of WP_Query args.
	 */
	function csco_related_posts_args( $args ) {
		global $powerkit_inline_posts;
		if ( ! $powerkit_inline_posts ) {
			return $args;
		}
		$post__not_in         = $args['post__not_in'];
		$post__not_in         = array_unique( array_merge( $post__not_in, $powerkit_inline_posts ) );
		$args['post__not_in'] = $post__not_in;
		return $args;
	}
}
add_filter( 'csco_related_posts_args', 'csco_related_posts_args' );

if ( ! function_exists( 'csco_powerkit_featured_posts_register' ) ) {
	/**
	 * Featured Posts Register Default Template
	 *
	 * @param array $templates The templates.
	 */
	function csco_powerkit_featured_posts_register( $templates = array() ) {
		$templates['large'] = array(
			'name' => esc_html__( 'Large', 'expertly' ),
			'func' => 'csco_powerkit_featured_posts_default_template',
		);
		return $templates;
	}
}
add_filter( 'powerkit_featured_posts_templates', 'csco_powerkit_featured_posts_register' );

if ( ! function_exists( 'csco_powerkit_featured_posts_default_template' ) ) {
	/**
	 * Featured Posts Markup Default Template
	 *
	 * @param array $posts    Array of posts.
	 * @param array $params   Array of params.
	 * @param array $instance Widget instance.
	 */
	function csco_powerkit_featured_posts_default_template( $posts, $params, $instance ) {
		if ( $params['post_meta_category'] ) {
			$params['post_meta'] = 'category';
		}
		?>
		<article <?php post_class(); ?>>
			<div class="cs-overlay cs-overlay-hover cs-overlay-ratio cs-ratio-landscape cs-bg-dark">
				<div class="cs-overlay-background">
					<?php the_post_thumbnail( 'pk-thumbnail' ); ?>
				</div>
				<div class="cs-overlay-content">
					<?php csco_the_post_format_icon(); ?>
					<?php csco_get_post_meta( 'category', false, true, $params['post_meta'] ); ?>
					<?php csco_get_post_meta( array( 'reading_time', 'views' ), (bool) $params['post_meta_compact'], true, $params['post_meta'] ); ?>
				</div>
				<a href="<?php the_permalink(); ?>" class="cs-overlay-link"></a>
			</div>
			<div class="cs-card">
				<h2 class="h5 entry-title">
					<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
				</h2>
				<?php csco_get_post_meta( array( 'date', 'shares' ), (bool) $params['post_meta_compact'], true, $params['post_meta'] ); ?>
			</div>
		</article>
		<?php
	}
}
