<?php
/**
 * Page Settings
 *
 * @package Expertly
 */

CSCO_Kirki::add_section(
	'page_settings', array(
		'title'    => esc_html__( 'Page Settings', 'expertly' ),
		'priority' => 50,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'page_sidebar',
		'label'    => esc_html__( 'Default Sidebar', 'expertly' ),
		'section'  => 'page_settings',
		'default'  => 'right',
		'priority' => 10,
		'choices'  => array(
			'right'    => esc_attr__( 'Right Sidebar', 'expertly' ),
			'left'     => esc_attr__( 'Left Sidebar', 'expertly' ),
			'disabled' => esc_attr__( 'No Sidebar', 'expertly' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'page_header_type',
		'label'    => esc_html__( 'Page Header Type', 'expertly' ),
		'section'  => 'page_settings',
		'default'  => 'standard',
		'priority' => 10,
		'choices'  => array(
			'none'     => esc_attr__( 'None', 'expertly' ),
			'standard' => esc_attr__( 'Standard', 'expertly' ),
			'small'    => esc_attr__( 'Small', 'expertly' ),
			'overlay'  => esc_attr__( 'Overlay', 'expertly' ),
			'title'    => esc_attr__( 'Page Title Only', 'expertly' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'page_excerpt',
		'label'    => esc_html__( 'Display excerpts', 'expertly' ),
		'section'  => 'page_settings',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'page_comments_simple',
		'label'    => esc_html__( 'Display comments without the View Comments button', 'expertly' ),
		'section'  => 'page_settings',
		'default'  => false,
		'priority' => 10,
	)
);
