<?php
/**
 * Homepage Settings
 *
 * @package Expertly
 */

/**
 * Removes default WordPress Static Front Page section
 * and re-adds it in our own panel with the same parameters.
 *
 * @param object $wp_customize Instance of the WP_Customize_Manager class.
 */
function csco_reorder_customizer_settings( $wp_customize ) {

	// Get current front page section parameters.
	$static_front_page = $wp_customize->get_section( 'static_front_page' );

	// Remove existing section, so that we can later re-add it to our panel.
	$wp_customize->remove_section( 'static_front_page' );

	// Re-add static front page section with a new name, but same description.
	$wp_customize->add_section( 'static_front_page', array(
		'title'           => esc_html__( 'Static Front Page', 'expertly' ),
		'priority'        => 20,
		'description'     => $static_front_page->description,
		'panel'           => 'homepage_settings',
		'active_callback' => $static_front_page->active_callback,
	) );
}
add_action( 'customize_register', 'csco_reorder_customizer_settings' );

CSCO_Kirki::add_panel(
	'homepage_settings', array(
		'title'    => esc_html__( 'Homepage Settings', 'expertly' ),
		'priority' => 50,
	)
);

CSCO_Kirki::add_section(
	'homepage_layout', array(
		'title'    => esc_html__( 'Homepage Layout', 'expertly' ),
		'priority' => 15,
		'panel'    => 'homepage_settings',
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'home_layout',
		'label'    => esc_html__( 'Layout', 'expertly' ),
		'section'  => 'homepage_layout',
		'default'  => 'grid',
		'priority' => 10,
		'choices'  => array(
			'full'         => esc_html__( 'Full Post Layout', 'expertly' ),
			'list'         => esc_html__( 'List Layout', 'expertly' ),
			'full-list'    => esc_html__( '1 Full then List', 'expertly' ),
			'grid'         => esc_html__( 'Grid Layout', 'expertly' ),
			'full-grid'    => esc_html__( '1 Full then Grid', 'expertly' ),
			'masonry'      => esc_html__( 'Masonry Layout', 'expertly' ),
			'full-masonry' => esc_html__( '1 Full then Masonry', 'expertly' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'home_sidebar',
		'label'    => esc_html__( 'Sidebar', 'expertly' ),
		'section'  => 'homepage_layout',
		'default'  => 'right',
		'priority' => 10,
		'choices'  => array(
			'right'    => esc_attr__( 'Right Sidebar', 'expertly' ),
			'left'     => esc_attr__( 'Left Sidebar', 'expertly' ),
			'disabled' => esc_attr__( 'No Sidebar', 'expertly' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'multicheck',
		'settings' => 'home_post_meta',
		'label'    => esc_attr__( 'Post Meta', 'expertly' ),
		'section'  => 'homepage_layout',
		'default'  => array( 'category', 'date', 'author', 'comments', 'shares', 'views', 'reading_time' ),
		'priority' => 10,
		'choices'  => apply_filters( 'csco_post_meta_choices', array(
			'category'     => esc_html__( 'Category', 'expertly' ),
			'date'         => esc_html__( 'Date', 'expertly' ),
			'author'       => esc_html__( 'Author', 'expertly' ),
			'shares'       => esc_html__( 'Shares', 'expertly' ),
			'views'        => esc_html__( 'Views', 'expertly' ),
			'comments'     => esc_html__( 'Comments', 'expertly' ),
			'reading_time' => esc_html__( 'Reading Time', 'expertly' ),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'home_summary',
		'label'           => esc_html__( 'Full Post Summary', 'expertly' ),
		'section'         => 'homepage_layout',
		'default'         => 'excerpt',
		'priority'        => 10,
		'choices'         => array(
			'excerpt' => esc_html__( 'Use Excerpts', 'expertly' ),
			'content' => esc_html__( 'Use Read More Tag', 'expertly' ),
		),
		'active_callback' => array(
			array(
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'full',
				),
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'full-list',
				),
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'full-grid',
				),
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'full-masonry',
				),
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'home_more_button',
		'label'    => esc_html__( 'Display View Post button', 'expertly' ),
		'section'  => 'homepage_layout',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'home_pagination_type',
		'label'    => esc_html__( 'Pagination', 'expertly' ),
		'section'  => 'homepage_layout',
		'default'  => 'standard',
		'priority' => 10,
		'choices'  => array(
			'standard'  => esc_html__( 'Standard', 'expertly' ),
			'load-more' => esc_html__( 'Load More Button', 'expertly' ),
			'infinite'  => esc_html__( 'Infinite Load', 'expertly' ),
		),
	)
);

CSCO_Kirki::add_section(
	'hero', array(
		'title'    => esc_html__( 'Hero Section', 'expertly' ),
		'panel'    => 'homepage_settings',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'hero',
		'label'    => esc_html__( 'Display hero section', 'expertly' ),
		'section'  => 'hero',
		'default'  => false,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'text',
		'settings'        => 'hero_height',
		'label'           => esc_html__( 'Hero Minimum Height', 'expertly' ),
		'description'     => esc_html__( 'Input minimum height in pixels. Hero section will stretch automatically, if the content doesn\'t fit in the available space.', 'expertly' ),
		'section'         => 'hero',
		'default'         => '600px',
		'priority'        => 10,
		'output'          => array(
			array(
				'element'     => '.section-hero',
				'property'    => 'min-height',
				'media_query' => '@media (min-width: 1020px)',
			),
		),
		'active_callback' => array(
			array(
				'setting'  => 'hero',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);


CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'hero_location',
		'label'           => esc_html__( 'Display Location', 'expertly' ),
		'section'         => 'hero',
		'default'         => 'front_page',
		'priority'        => 10,
		'choices'         => array(
			'front_page' => esc_html__( 'Homepage', 'expertly' ),
			'home'       => esc_html__( 'Posts page', 'expertly' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'hero',
				'operator' => '==',
				'value'    => true,
			),
			array(
				'setting'  => 'show_on_front',
				'operator' => '==',
				'value'    => 'page',
			),
		),
	)
);

CSCO_Kirki::add_field( 'csco_theme_mod', array(
	'type'            => 'image',
	'settings'        => 'hero_logo',
	'label'           => esc_html__( 'Logo Image', 'expertly' ),
	'description'     => esc_html__( 'Logo image will be displayed in its original image dimensions. For support of Retina screens, please upload the 2x version of your logo via Media Library with ', 'expertly' ) . '<code>@2x</code>' . esc_html__( ' suffix. For example.', 'expertly' ) . '<code>logo-homepage@2x.png</code>',
	'section'         => 'hero',
	'default'         => '',
	'priority'        => 10,
	'choices'         => array(
		'save_as' => 'id',
	),
	'active_callback' => array(
		array(
			'setting'  => 'hero',
			'operator' => '==',
			'value'    => true,
		),
	),
));


CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'              => 'text',
		'settings'          => 'hero_title',
		'label'             => esc_html__( 'Title', 'expertly' ),
		'section'           => 'hero',
		'default'           => get_bloginfo( 'name' ),
		'priority'          => 10,
		'sanitize_callback' => 'wp_kses_post',
		'active_callback'   => array(
			array(
				'setting'  => 'hero',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'textarea',
		'settings'        => 'hero_lead',
		'label'           => esc_html__( 'Lead', 'expertly' ),
		'section'         => 'hero',
		'default'         => get_bloginfo( 'description' ),
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'hero',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'hero_search_form',
		'label'           => esc_html__( 'Display Search Form', 'expertly' ),
		'section'         => 'hero',
		'default'         => true,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'hero',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'hero_subscription_form',
		'label'           => esc_html__( 'Display Subscription Form', 'expertly' ),
		'section'         => 'hero',
		'default'         => false,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'hero',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'hero_subscription_name',
		'label'           => esc_html__( 'Display first name field', 'expertly' ),
		'section'         => 'hero',
		'default'         => false,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'hero',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'hero_alignment',
		'label'           => esc_html__( 'Content Position', 'expertly' ),
		'section'         => 'hero',
		'default'         => 'left',
		'priority'        => 10,
		'choices'         => array(
			'left'   => esc_html__( 'Left', 'expertly' ),
			'center' => esc_html__( 'Center', 'expertly' ),
			'right'  => esc_html__( 'Right', 'expertly' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'hero',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'image',
		'settings'        => 'hero_background_image',
		'label'           => esc_html__( 'Hero Image', 'expertly' ),
		'section'         => 'hero',
		'priority'        => 10,
		'choices'         => array(
			'save_as' => 'id',
		),
		'active_callback' => array(
			array(
				'setting'  => 'hero',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'hero_background_image_outside',
		'label'           => esc_html__( 'Display hero image outsite hero content ', 'expertly' ),
		'section'         => 'hero',
		'default'         => false,
		'priority'        => 10,
		'active_callback' => array(
			array(
				array(
					'setting'  => 'hero',
					'operator' => '==',
					'value'    => true,
				),
			),
			array(
				array(
					'setting'  => 'hero_alignment',
					'operator' => '==',
					'value'    => 'left',
				),
				array(
					'setting'  => 'hero_alignment',
					'operator' => '==',
					'value'    => 'right',
				),
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'slider',
		'settings'        => 'hero_image_opacity',
		'label'           => esc_html__( 'Hero Image Opacity', 'expertly' ),
		'section'         => 'hero',
		'default'         => 1,
		'choices'         => array(
			'min'  => '0.1',
			'max'  => '1',
			'step' => '0.1',
		),
		'transport'       => 'auto',
		'output'          => apply_filters( 'csco_hero_image_opacity', array(
			array(
				'element'  => '.section-hero .cs-overlay-background img',
				'property' => 'opacity',
			),
		) ),
		'active_callback' => array(
			array(
				'setting'  => 'hero',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'color',
		'settings'        => 'hero_background_color',
		'label'           => esc_html__( 'Background Color', 'expertly' ),
		'section'         => 'hero',
		'default'         => '#F8F8F8',
		'priority'        => 10,
		'output'          => apply_filters( 'csco_hero_background_color', array(
			array(
				'element'  => '.section-hero',
				'property' => 'background-color',
			),
		) ),
		'active_callback' => array(
			array(
				'setting'  => 'hero',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_section(
	'featured_posts', array(
		'title'    => esc_html__( 'Featured Posts', 'expertly' ),
		'panel'    => 'homepage_settings',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'featured_posts',
		'label'    => esc_html__( 'Display featured posts', 'expertly' ),
		'section'  => 'featured_posts',
		'default'  => false,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'featured_posts_location',
		'label'           => esc_html__( 'Display Location', 'expertly' ),
		'section'         => 'featured_posts',
		'default'         => 'front_page',
		'priority'        => 10,
		'choices'         => array(
			'front_page' => esc_html__( 'Homepage', 'expertly' ),
			'home'       => esc_html__( 'Posts page', 'expertly' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'featured_posts',
				'operator' => '==',
				'value'    => true,
			),
			array(
				'setting'  => 'show_on_front',
				'operator' => '==',
				'value'    => 'page',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'text',
		'settings'        => 'featured_posts_filter_categories',
		'label'           => esc_html__( 'Filter by Categories', 'expertly' ),
		'description'     => esc_html__( 'Add comma-separated list of category slugs. For example: &laquo;travel, lifestyle, food&raquo;. Leave empty for all categories.', 'expertly' ),
		'section'         => 'featured_posts',
		'default'         => '',
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'featured_posts',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'text',
		'settings'        => 'featured_posts_filter_tags',
		'label'           => esc_html__( 'Filter by Tags', 'expertly' ),
		'description'     => esc_html__( 'Add comma-separated list of tag slugs. For example: &laquo;worth-reading, top-5, playlists&raquo;. Leave empty for all tags.', 'expertly' ),
		'section'         => 'featured_posts',
		'default'         => '',
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'featured_posts',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'text',
		'settings'        => 'featured_posts_filter_posts',
		'label'           => esc_html__( 'Filter by Posts', 'expertly' ),
		'description'     => esc_html__( 'Add comma-separated list of post IDs. For example: 12, 34, 145. Leave empty for all posts.', 'expertly' ),
		'section'         => 'featured_posts',
		'default'         => '',
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'featured_posts',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

if ( class_exists( 'Post_Views_Counter' ) ) {

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'radio',
			'settings'        => 'featured_posts_orderby',
			'label'           => esc_html__( 'Order posts by', 'expertly' ),
			'section'         => 'featured_posts',
			'default'         => 'date',
			'priority'        => 10,
			'choices'         => array(
				'date'       => esc_html__( 'Date', 'expertly' ),
				'post_views' => esc_html__( 'Views', 'expertly' ),
			),
			'active_callback' => array(
				array(
					'setting'  => 'featured_posts',
					'operator' => '==',
					'value'    => true,
				),
			),
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'text',
			'settings'        => 'featured_posts_time_frame',
			'label'           => esc_html__( 'Filter by Time Frame', 'expertly' ),
			'description'     => esc_html__( 'Add period of posts in English. For example: &laquo;2 months&raquo;, &laquo;14 days&raquo; or even &laquo;1 year&raquo;', 'expertly' ),
			'section'         => 'featured_posts',
			'default'         => '',
			'priority'        => 10,
			'active_callback' => array(
				array(
					'setting'  => 'featured_posts',
					'operator' => '==',
					'value'    => true,
				),
				array(
					'setting'  => 'featured_posts_orderby',
					'operator' => '==',
					'value'    => 'post_views',
				),
			),
		)
	);

}

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'featured_posts_exclude',
		'label'           => esc_html__( 'Exclude featured posts from the main archive', 'expertly' ),
		'section'         => 'featured_posts',
		'default'         => false,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'featured_posts',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_section(
	'featured_categories', array(
		'title'    => esc_html__( 'Featured Categories', 'expertly' ),
		'panel'    => 'homepage_settings',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'featured_categories',
		'label'    => esc_html__( 'Display featured categories', 'expertly' ),
		'section'  => 'featured_categories',
		'default'  => false,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'featured_categories_location',
		'label'           => esc_html__( 'Display Location', 'expertly' ),
		'section'         => 'featured_categories',
		'default'         => 'front_page',
		'priority'        => 10,
		'choices'         => array(
			'front_page' => esc_html__( 'Homepage', 'expertly' ),
			'home'       => esc_html__( 'Posts page', 'expertly' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'featured_categories',
				'operator' => '==',
				'value'    => true,
			),
			array(
				'setting'  => 'show_on_front',
				'operator' => '==',
				'value'    => 'page',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'text',
		'settings'        => 'featured_categories_slug',
		'label'           => esc_html__( 'Include Categories', 'expertly' ),
		'description'     => esc_html__( 'Add comma-separated list of category slugs. For example: &laquo;travel, lifestyle, food&raquo;. Leave empty for all categories.', 'expertly' ),
		'section'         => 'featured_categories',
		'default'         => '',
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'featured_categories',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'text',
		'settings'        => 'featured_categories_exclude',
		'label'           => esc_html__( 'Exclude Categories', 'expertly' ),
		'description'     => esc_html__( 'Add comma-separated list of category slugs. For example: &laquo;travel, lifestyle, food&raquo;.', 'expertly' ),
		'section'         => 'featured_categories',
		'default'         => '',
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'featured_categories',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'featured_categories_orderby',
		'label'           => esc_html__( 'Order categories by', 'expertly' ),
		'section'         => 'featured_categories',
		'default'         => 'title',
		'priority'        => 10,
		'choices'         => array(
			'title'    => esc_html__( 'Title', 'expertly' ),
			'count'    => esc_html__( 'Post Count', 'expertly' ),
			'slug__in' => esc_html__( 'Custom', 'expertly' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'featured_categories',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'featured_categories_order',
		'label'           => esc_html__( 'Category Order', 'expertly' ),
		'section'         => 'featured_categories',
		'default'         => 'DESC',
		'priority'        => 10,
		'choices'         => array(
			'ASC'  => esc_html__( 'Ascending', 'expertly' ),
			'DESC' => esc_html__( 'Descending', 'expertly' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'featured_categories',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

if ( class_exists( 'Post_Views_Counter' ) ) {

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'radio',
			'settings'        => 'featured_categories_orderby_posts',
			'label'           => esc_html__( 'Order posts by', 'expertly' ),
			'section'         => 'featured_categories',
			'default'         => 'date',
			'priority'        => 10,
			'choices'         => array(
				'date'       => esc_html__( 'Date', 'expertly' ),
				'post_views' => esc_html__( 'Views', 'expertly' ),
			),
			'active_callback' => array(
				array(
					'setting'  => 'featured_categories',
					'operator' => '==',
					'value'    => true,
				),
			),
		)
	);

}

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'number',
		'settings'        => 'featured_categories_number',
		'label'           => esc_html__( 'Number of Categories', 'expertly' ),
		'description'     => esc_html__( 'Maximum number of categories to return.', 'expertly' ),
		'section'         => 'featured_categories',
		'default'         => 3,
		'choices'         => array(
			'min'  => '0',
			'max'  => '999',
			'step' => '1',
		),
		'active_callback' => array(
			array(
				'setting'  => 'featured_categories',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'number',
		'settings'        => 'featured_categories_posts_per_page',
		'label'           => esc_html__( 'Number of Posts', 'expertly' ),
		'section'         => 'featured_categories',
		'default'         => 5,
		'choices'         => array(
			'min'  => '0',
			'max'  => '99',
			'step' => '1',
		),
		'active_callback' => array(
			array(
				'setting'  => 'featured_categories',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'number',
		'settings'        => 'featured_categories_columns',
		'label'           => esc_html__( 'Number of Columns', 'expertly' ),
		'section'         => 'featured_categories',
		'default'         => 3,
		'choices'         => array(
			'min'  => '2',
			'max'  => '4',
			'step' => '1',
		),
		'active_callback' => array(
			array(
				'setting'  => 'featured_categories',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);


CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'featured_categories_featured_exclude',
		'label'           => esc_html__( 'Exclude first posts from the featured and footer posts section', 'expertly' ),
		'section'         => 'featured_categories',
		'default'         => false,
		'active_callback' => array(
			array(
				'setting'  => 'featured_categories',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'featured_categories_archive_exclude',
		'label'           => esc_html__( 'Exclude first posts from the main archive', 'expertly' ),
		'section'         => 'featured_categories',
		'default'         => false,
		'active_callback' => array(
			array(
				'setting'  => 'featured_categories',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);
