<?php
/**
 * Category Settings
 *
 * @package Expertly
 */

CSCO_Kirki::add_section(
	'category_settings', array(
		'title'    => esc_html__( 'Category Settings', 'expertly' ),
		'priority' => 50,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'category_featured_posts',
		'label'    => esc_html__( 'Display featured posts', 'expertly' ),
		'section'  => 'category_settings',
		'default'  => false,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'text',
		'settings'        => 'category_featured_posts_filter_tags',
		'label'           => esc_html__( 'Filter by Tags', 'expertly' ),
		'description'     => esc_html__( 'Add comma-separated list of tag slugs. For example: &laquo;worth-reading, top-5, playlists&raquo;. Leave empty for all tags.', 'expertly' ),
		'section'         => 'category_settings',
		'default'         => '',
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'category_featured_posts',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'text',
		'settings'        => 'category_featured_posts_filter_posts',
		'label'           => esc_html__( 'Filter by Posts', 'expertly' ),
		'description'     => esc_html__( 'Add comma-separated list of post IDs. For example: 12, 34, 145. Leave empty for all posts.', 'expertly' ),
		'section'         => 'category_settings',
		'default'         => '',
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'category_featured_posts',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

if ( class_exists( 'Post_Views_Counter' ) ) {

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'radio',
			'settings'        => 'category_featured_posts_orderby',
			'label'           => esc_html__( 'Order posts by', 'expertly' ),
			'section'         => 'category_settings',
			'default'         => 'date',
			'priority'        => 10,
			'choices'         => array(
				'date'       => esc_html__( 'Date', 'expertly' ),
				'post_views' => esc_html__( 'Views', 'expertly' ),
			),
			'active_callback' => array(
				array(
					'setting'  => 'category_featured_posts',
					'operator' => '==',
					'value'    => true,
				),
			),
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'text',
			'settings'        => 'category_featured_posts_time_frame',
			'label'           => esc_html__( 'Filter by Time Frame', 'expertly' ),
			'description'     => esc_html__( 'Add period of posts in English. For example: &laquo;2 months&raquo;, &laquo;14 days&raquo; or even &laquo;1 year&raquo;', 'expertly' ),
			'section'         => 'category_settings',
			'default'         => '',
			'priority'        => 10,
			'active_callback' => array(
				array(
					'setting'  => 'category_featured_posts',
					'operator' => '==',
					'value'    => true,
				),
				array(
					'setting'  => 'category_featured_posts_orderby',
					'operator' => '==',
					'value'    => 'post_views',
				),
			),
		)
	);

}

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'category_featured_posts_exclude',
		'label'           => esc_html__( 'Exclude featured posts from the category archive', 'expertly' ),
		'section'         => 'category_settings',
		'default'         => false,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'category_featured_posts',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'category_subcategories',
		'label'    => esc_html__( 'Display subcategory filter', 'expertly' ),
		'section'  => 'category_settings',
		'default'  => false,
		'priority' => 10,
	)
);
