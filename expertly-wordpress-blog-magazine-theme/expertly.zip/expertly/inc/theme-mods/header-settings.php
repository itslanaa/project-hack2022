<?php
/**
 * Header Settings
 *
 * @package Expertly
 */

CSCO_Kirki::add_section(
	'header', array(
		'title'    => esc_html__( 'Header Settings', 'expertly' ),
		'priority' => 40,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'navbar_site_description',
		'label'    => esc_html__( 'Display tagline in navigation bar', 'expertly' ),
		'section'  => 'header',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'checkbox',
		'settings'    => 'navbar_sticky',
		'label'       => esc_html__( 'Make navigation bar sticky', 'expertly' ),
		'description' => esc_html__( 'Enabling this option will make navigation bar visible when scrolling.', 'expertly' ),
		'section'     => 'header',
		'default'     => true,
		'priority'    => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'effects_navbar_scroll',
		'label'           => esc_html__( 'Enable the smart sticky feature', 'expertly' ),
		'description'     => esc_html__( 'Enabling this option will reveal navigation bar when scrolling up and hide it when scrolling down.', 'expertly' ),
		'section'         => 'header',
		'default'         => true,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'navbar_sticky',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

if ( csco_powerkit_module_enabled( 'social_links' ) ) {
	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'     => 'checkbox',
			'settings' => 'header_social_links',
			'label'    => esc_html__( 'Display social links', 'expertly' ),
			'section'  => 'header',
			'default'  => false,
			'priority' => 10,
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'select',
			'settings'        => 'header_social_links_scheme',
			'label'           => esc_html__( 'Color scheme', 'expertly' ),
			'section'         => 'header',
			'default'         => 'light',
			'priority'        => 10,
			'choices'         => array(
				'light'         => esc_html__( 'Light', 'expertly' ),
				'bold'          => esc_html__( 'Bold', 'expertly' ),
				'light-rounded' => esc_html__( 'Light Rounded', 'expertly' ),
				'bold-rounded'  => esc_html__( 'Bold Rounded', 'expertly' ),
			),
			'active_callback' => array(
				array(
					'setting'  => 'header_social_links',
					'operator' => '==',
					'value'    => true,
				),
			),
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'number',
			'settings'        => 'header_social_links_maximum',
			'label'           => esc_html__( 'Maximum Number of Social Links', 'expertly' ),
			'section'         => 'header',
			'default'         => 3,
			'priority'        => 10,
			'active_callback' => array(
				array(
					'setting'  => 'header_social_links',
					'operator' => '==',
					'value'    => true,
				),
			),
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'checkbox',
			'settings'        => 'header_social_links_counts',
			'label'           => esc_html__( 'Display social counts', 'expertly' ),
			'section'         => 'header',
			'default'         => true,
			'priority'        => 10,
			'active_callback' => array(
				array(
					'setting'  => 'header_social_links',
					'operator' => '==',
					'value'    => true,
				),
			),
		)
	);
}

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'header_search_button',
		'label'    => esc_html__( 'Display search button', 'expertly' ),
		'section'  => 'header',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'number',
		'settings' => 'header_mega_menu_rows',
		'label'    => esc_html__( 'Number of post rows in Mega Menus', 'expertly' ),
		'section'  => 'header',
		'default'  => 1,
		'priority' => 10,
	)
);
CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'header_mega_menu_order',
		'label'    => esc_html__( 'Category Order', 'expertly' ),
		'section'  => 'header',
		'default'  => 'ASC',
		'priority' => 10,
		'choices'  => array(
			'ASC'  => esc_html__( 'Ascending', 'expertly' ),
			'DESC' => esc_html__( 'Descending', 'expertly' ),
		),
	)
);

if ( class_exists( 'Post_Views_Counter' ) ) {

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'     => 'radio',
			'settings' => 'header_mega_menu_orderby',
			'label'    => esc_html__( 'Order posts by', 'expertly' ),
			'section'  => 'header',
			'default'  => 'date',
			'priority' => 10,
			'choices'  => array(
				'date'       => esc_html__( 'Date', 'expertly' ),
				'post_views' => esc_html__( 'Views', 'expertly' ),
			),
		)
	);
}
