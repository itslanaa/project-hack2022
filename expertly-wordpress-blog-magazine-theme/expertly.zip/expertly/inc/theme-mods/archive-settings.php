<?php
/**
 * Archive Settings
 *
 * @package Expertly
 */

CSCO_Kirki::add_section(
	'archive_settings', array(
		'title'    => esc_html__( 'Archive Settings', 'expertly' ),
		'priority' => 50,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'archive_layout',
		'label'    => esc_html__( 'Layout', 'expertly' ),
		'section'  => 'archive_settings',
		'default'  => 'grid',
		'priority' => 10,
		'choices'  => array(
			'full'         => esc_html__( 'Full Post Layout', 'expertly' ),
			'list'         => esc_html__( 'List Layout', 'expertly' ),
			'full-list'    => esc_html__( '1 Full then List', 'expertly' ),
			'grid'         => esc_html__( 'Grid Layout', 'expertly' ),
			'full-grid'    => esc_html__( '1 Full then Grid', 'expertly' ),
			'masonry'      => esc_html__( 'Masonry Layout', 'expertly' ),
			'full-masonry' => esc_html__( '1 Full then Masonry', 'expertly' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'archive_sidebar',
		'label'    => esc_html__( 'Sidebar', 'expertly' ),
		'section'  => 'archive_settings',
		'default'  => 'right',
		'priority' => 10,
		'choices'  => array(
			'right'    => esc_attr__( 'Right Sidebar', 'expertly' ),
			'left'     => esc_attr__( 'Left Sidebar', 'expertly' ),
			'disabled' => esc_attr__( 'No Sidebar', 'expertly' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'multicheck',
		'settings' => 'archive_post_meta',
		'label'    => esc_attr__( 'Post Meta', 'expertly' ),
		'section'  => 'archive_settings',
		'default'  => array( 'category', 'date', 'author', 'comments', 'shares', 'views', 'reading_time' ),
		'priority' => 10,
		'choices'  => apply_filters( 'csco_post_meta_choices', array(
			'category'     => esc_html__( 'Category', 'expertly' ),
			'date'         => esc_html__( 'Date', 'expertly' ),
			'author'       => esc_html__( 'Author', 'expertly' ),
			'shares'       => esc_html__( 'Shares', 'expertly' ),
			'views'        => esc_html__( 'Views', 'expertly' ),
			'comments'     => esc_html__( 'Comments', 'expertly' ),
			'reading_time' => esc_html__( 'Reading Time', 'expertly' ),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'archive_summary',
		'label'           => esc_html__( 'Full Post Summary', 'expertly' ),
		'section'         => 'archive_settings',
		'default'         => 'excerpt',
		'priority'        => 10,
		'choices'         => array(
			'excerpt' => esc_html__( 'Use Excerpts', 'expertly' ),
			'content' => esc_html__( 'Use Read More Tag', 'expertly' ),
		),
		'active_callback' => array(
			array(
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'full',
				),
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'full-list',
				),
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'full-grid',
				),
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'full-masonry',
				),
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'archive_more_button',
		'label'    => esc_html__( 'Display View Post button', 'expertly' ),
		'section'  => 'archive_settings',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'archive_pagination_type',
		'label'    => esc_html__( 'Pagination', 'expertly' ),
		'section'  => 'archive_settings',
		'default'  => 'standard',
		'priority' => 10,
		'choices'  => array(
			'standard'  => esc_html__( 'Standard', 'expertly' ),
			'load-more' => esc_html__( 'Load More Button', 'expertly' ),
			'infinite'  => esc_html__( 'Infinite Load', 'expertly' ),
		),
	)
);
