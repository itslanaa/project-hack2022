<?php
/**
 * Miscellaneous Settings
 *
 * @package Expertly
 */

CSCO_Kirki::add_section(
	'miscellaneous', array(
		'title'    => esc_html__( 'Miscellaneous Settings', 'expertly' ),
		'priority' => 60,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'display_published_date',
		'label'    => esc_html__( 'Display published date instead of modified date', 'expertly' ),
		'section'  => 'miscellaneous',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'              => 'text',
		'settings'          => 'miscellaneous_border_radius',
		'label'             => esc_html__( 'Border Radius', 'expertly' ),
		'description'       => esc_html__( 'For example: 30px. If the input is empty, original value will be used.', 'expertly' ),
		'section'           => 'miscellaneous',
		'default'           => '',
		'priority'          => 10,
		'sanitize_callback' => 'esc_html',
		'output'            => apply_filters( 'csco_misc_border_radius', array(
			array(
				'element'  => 'button, input[type="button"], input[type="reset"], input[type="submit"], .button, .cs-input-group input[type="search"], .pk-button, .pk-input-group input[type="text"], .pk-scroll-to-top, .cs-overlay .post-categories a, .search-form, .cs-input-group, .pk-input-group, .pk-subscribe-form-wrap form, .widget .pk-subscribe-form-wrap.pk-subscribe-with-bg input[type="text"], .post-header .pk-share-buttons-wrap .pk-share-buttons-link, .pk-share-buttons-after-content .pk-share-buttons-link, .pk-dropcap-borders:first-letter, .pk-dropcap-bg-inverse:first-letter, .pk-dropcap-bg-light:first-letter',
				'property' => 'border-radius',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'text',
		'settings' => 'search_placeholder',
		'label'    => esc_html__( 'Search Form Placeholder', 'expertly' ),
		'section'  => 'miscellaneous',
		'default'  => esc_html__( 'Input your search keywords', 'expertly' ),
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'text',
		'settings' => 'label_readmore',
		'label'    => esc_html__( '"View Post" Button Label', 'expertly' ),
		'section'  => 'miscellaneous',
		'default'  => esc_html__( 'View Post', 'expertly' ),
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'classic_gallery_alignment',
		'label'    => esc_html__( 'Alignment of Galleries in Classic Block', 'expertly' ),
		'section'  => 'miscellaneous',
		'default'  => 'default',
		'priority' => 10,
		'choices'  => array(
			'default' => esc_html__( 'Default', 'expertly' ),
			'wide'    => esc_html__( 'Wide', 'expertly' ),
			'large'   => esc_html__( 'Large', 'expertly' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'sticky_sidebar',
		'label'    => esc_html__( 'Sticky Sidebar', 'expertly' ),
		'section'  => 'miscellaneous',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'sticky_sidebar_method',
		'label'           => esc_html__( 'Sticky Method', 'expertly' ),
		'section'         => 'miscellaneous',
		'default'         => 'stick-to-top',
		'priority'        => 10,
		'choices'         => array(
			'stick-to-top'    => esc_html__( 'Sidebar top edge', 'expertly' ),
			'stick-to-bottom' => esc_html__( 'Sidebar bottom edge', 'expertly' ),
			'stick-last'      => esc_html__( 'Last widget top edge', 'expertly' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'sticky_sidebar',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'radio',
		'settings'    => 'webfonts_load_method',
		'label'       => esc_html__( 'Webfonts Load Method', 'expertly' ),
		'description' => esc_html__( 'Please', 'expertly' ) . ' <a href="' . add_query_arg( array( 'action' => 'kirki-reset-cache' ), get_site_url() ) . '" target="_blank">' . esc_html__( 'reset font cache', 'overflow' ) . '</a> ' . esc_html__( 'after saving.', 'overflow' ),
		'section'     => 'miscellaneous',
		'default'     => 'async',
		'priority'    => 10,
		'choices'     => array(
			'async' => esc_html__( 'Asynchronous', 'expertly' ),
			'link'  => esc_html__( 'Render-Blocking', 'expertly' ),
		),
	)
);
