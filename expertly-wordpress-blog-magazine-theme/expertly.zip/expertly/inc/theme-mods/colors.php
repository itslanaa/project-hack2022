<?php
/**
 * Colors
 *
 * @package Expertly
 */

CSCO_Kirki::add_section(
	'colors', array(
		'title'    => esc_html__( 'Colors', 'expertly' ),
		'priority' => 20,
	)
);

/**
 * -------------------------------------------------------------------------
 * Base
 * -------------------------------------------------------------------------
 */

CSCO_Kirki::add_section(
	'colors_base', array(
		'title'    => esc_html__( 'Base', 'expertly' ),
		'panel'    => 'colors',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'      => 'color',
		'settings'  => 'color_primary',
		'label'     => esc_html__( 'Primary Color', 'expertly' ),
		'section'   => 'colors',
		'priority'  => 10,
		'default'   => '#1384f5',
		'transport' => 'auto',
		'output'    => apply_filters( 'csco_color_primary', array(
			array(
				'element'  => 'a:hover, .entry-content a, .must-log-in a, .meta-category a, blockquote:before, .navbar-nav li.current-menu-ancestor > a, li.current-menu-item > a, li.cs-mega-menu-child.active-item > a, .cs-bg-dark.navbar-primary .navbar-nav ul li.current-menu-ancestor > a, .cs-bg-dark.navbar-primary .navbar-nav ul li.current-menu-item > a, .cs-bg-dark.navbar-primary .navbar-nav li.cs-mega-menu-child.active-item > a',
				'property' => 'color',
			),
			array(
				'element'  => 'button, .button, input[type="button"], input[type="reset"], input[type="submit"], .wp-block-button .wp-block-button__link:not(.has-background), .toggle-search.toggle-close, .offcanvas-header .toggle-offcanvas, .cs-overlay .post-categories a:hover, .post-format-icon > a:hover, .entry-more-button .entry-more:hover, .cs-list-articles > li > a:hover:before, .pk-badge-primary, .pk-bg-primary, .pk-button-primary, .pk-button-primary:hover, h2.pk-heading-numbered:before',
				'property' => 'background-color',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'      => 'color',
		'settings'  => 'color_overlay',
		'label'     => esc_html__( 'Overlay Color', 'expertly' ),
		'section'   => 'colors',
		'priority'  => 10,
		'default'   => 'rgba(0,0,0,0.25)',
		'transport' => 'auto',
		'choices'   => array(
			'alpha' => true,
		),
		'output'    => apply_filters( 'csco_color_overlay', array(
			array(
				'element'  => '.cs-overlay .cs-overlay-background:after, .pk-bg-overlay, .pk-zoom-icon-popup:after',
				'property' => 'background-color',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'color',
		'settings' => 'color_navbar_bg',
		'label'    => esc_html__( 'Navigation Bar Background', 'expertly' ),
		'section'  => 'colors',
		'default'  => '#FFFFFF',
		'priority' => 10,
		'output'   => array(
			array(
				'element'  => '.navbar-primary, .offcanvas-header',
				'property' => 'background-color',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'color',
		'settings' => 'color_footer_bg',
		'label'    => esc_html__( 'Footer Background', 'expertly' ),
		'section'  => 'colors',
		'default'  => '#ffffff',
		'priority' => 10,
		'output'   => array(
			array(
				'element'  => '.site-footer',
				'property' => 'background-color',
			),
		),
	)
);
