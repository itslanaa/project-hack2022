<?php
/**
 * Footer Settings
 *
 * @package Expertly
 */

CSCO_Kirki::add_section(
	'footer', array(
		'title'    => esc_html__( 'Footer Settings', 'expertly' ),
		'priority' => 40,
	)
);


CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'              => 'text',
		'settings'          => 'footer_title',
		'label'             => esc_attr__( 'Footer Title', 'expertly' ),
		'section'           => 'footer',
		'default'           => get_bloginfo( 'name' ),
		'priority'          => 10,
		'sanitize_callback' => 'wp_kses_post',
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'              => 'textarea',
		'settings'          => 'footer_text',
		'label'             => esc_attr__( 'Footer Text', 'expertly' ),
		'section'           => 'footer',
		/* translators: %s: Author name. */
		'default'           => sprintf( esc_html__( 'Designed & Developed by %s', 'expertly' ), '<a href="https://codesupply.co/">Code Supply Co.</a>' ),
		'priority'          => 10,
		'sanitize_callback' => 'wp_kses_post',
	)
);

if ( csco_powerkit_module_enabled( 'social_links' ) ) {
	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'     => 'checkbox',
			'settings' => 'footer_social_links',
			'label'    => esc_html__( 'Display social links', 'expertly' ),
			'section'  => 'footer',
			'default'  => false,
			'priority' => 10,
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'select',
			'settings'        => 'footer_social_links_scheme',
			'label'           => esc_html__( 'Color scheme', 'expertly' ),
			'section'         => 'footer',
			'default'         => 'light',
			'priority'        => 10,
			'choices'         => array(
				'light'         => esc_html__( 'Light', 'expertly' ),
				'bold'          => esc_html__( 'Bold', 'expertly' ),
				'light-rounded' => esc_html__( 'Light Rounded', 'expertly' ),
				'bold-rounded'  => esc_html__( 'Bold Rounded', 'expertly' ),
			),
			'active_callback' => array(
				array(
					'setting'  => 'footer_social_links',
					'operator' => '==',
					'value'    => true,
				),
			),
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'number',
			'settings'        => 'footer_social_links_maximum',
			'label'           => esc_html__( 'Maximum Number of Social Links', 'expertly' ),
			'section'         => 'footer',
			'default'         => 5,
			'priority'        => 10,
			'active_callback' => array(
				array(
					'setting'  => 'footer_social_links',
					'operator' => '==',
					'value'    => true,
				),
			),
		)
	);
}

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'footer_featured_posts',
		'label'    => esc_html__( 'Display featured posts', 'expertly' ),
		'section'  => 'footer',
		'default'  => false,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'text',
		'settings'        => 'footer_featured_posts_filter_categories',
		'label'           => esc_html__( 'Filter by Categories', 'expertly' ),
		'description'     => esc_html__( 'Add comma-separated list of category slugs. For example: &laquo;travel, lifestyle, food&raquo;. Leave empty for all categories.', 'expertly' ),
		'section'         => 'footer',
		'default'         => '',
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'footer_featured_posts',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'text',
		'settings'        => 'footer_featured_posts_filter_tags',
		'label'           => esc_html__( 'Filter by Tags', 'expertly' ),
		'description'     => esc_html__( 'Add comma-separated list of tag slugs. For example: &laquo;worth-reading, top-5, playlists&raquo;. Leave empty for all tags.', 'expertly' ),
		'section'         => 'footer',
		'default'         => '',
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'footer_featured_posts',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'text',
		'settings'        => 'footer_featured_posts_filter_posts',
		'label'           => esc_html__( 'Filter by Posts', 'expertly' ),
		'description'     => esc_html__( 'Add comma-separated list of post IDs. For example: 12, 34, 145. Leave empty for all posts.', 'expertly' ),
		'section'         => 'footer',
		'default'         => '',
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'footer_featured_posts',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

if ( class_exists( 'Post_Views_Counter' ) ) {

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'radio',
			'settings'        => 'footer_featured_posts_orderby',
			'label'           => esc_html__( 'Order posts by', 'expertly' ),
			'section'         => 'footer',
			'default'         => 'date',
			'priority'        => 10,
			'choices'         => array(
				'date'       => esc_html__( 'Date', 'expertly' ),
				'post_views' => esc_html__( 'Views', 'expertly' ),
			),
			'active_callback' => array(
				array(
					'setting'  => 'footer_featured_posts',
					'operator' => '==',
					'value'    => true,
				),
			),
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'text',
			'settings'        => 'footer_featured_posts_time_frame',
			'label'           => esc_html__( 'Filter by Time Frame', 'expertly' ),
			'description'     => esc_html__( 'Add period of posts in English. For example: &laquo;2 months&raquo;, &laquo;14 days&raquo; or even &laquo;1 year&raquo;', 'expertly' ),
			'section'         => 'footer',
			'default'         => '',
			'priority'        => 10,
			'active_callback' => array(
				array(
					'setting'  => 'footer_featured_posts',
					'operator' => '==',
					'value'    => true,
				),
				array(
					'setting'  => 'footer_featured_posts_orderby',
					'operator' => '==',
					'value'    => 'post_views',
				),
			),
		)
	);
}

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'footer_featured_posts_avoid_duplicate',
		'label'           => esc_html__( 'Exclude duplicate posts from the footer posts', 'expertly' ),
		'description'     => esc_html__( 'If enabled, posts from the featured posts section and post archive will not be shown in the footer section. The "Filter by Posts" option will override this option.', 'expertly' ),
		'section'         => 'footer',
		'default'         => false,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'footer_featured_posts',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);
