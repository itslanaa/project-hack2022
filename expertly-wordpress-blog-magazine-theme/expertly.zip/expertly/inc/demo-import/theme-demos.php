<?php
/**
 * Theme Demos
 *
 * @package Expertly
 */

/**
 * Theme Demos
 */
function csco_theme_demos() {
	$demos = array(
		// Theme mods imported with every demo.
		'common_mods' => array(),
		// Specific demos.
		'demos' => array(
			'expertly' => array(
				'name' => 'Expertly',
				'preview_image_url' => '/images/theme-demos/expertly.jpg',
				'mods' => array(
					'archive_layout' => 'grid',
					'archive_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'archive_sidebar' => 'right',
					'category_featured_posts' => true,
					'category_featured_posts_exclude' => true,
					'category_subcategories' => true,
					'color_primary' => '#02be8f',
					'featured_posts' => true,
					'featured_posts_exclude' => true,
					'footer_featured_posts' => true,
					'footer_social_links_scheme' => 'bold',
					'header_social_links_scheme' => 'light-rounded',
					'hero' => true,
					'hero_background_color' => '#495254',
					'hero_image_opacity' => 0.7,
					'hero_lead' => 'Subscribe to our blog updates and instantly receive our best-selling book &laquo;10 Productivity Myths&raquo; in PDF for free.',
					'hero_search_form' => false,
					'hero_subscription_form' => true,
					'hero_title' => 'Self-Made Entrepreneurs',
					'home_pagination_type' => 'load-more',
					'home_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'home_sidebar' => 'right',
					'post_header_type' => 'overlay',
					'post_subscribe' => true,
					'search_placeholder' => 'Input your search keywords',
					'sticky_sidebar_method' => 'stick-last'
				),
				'mods_typekit' => array(
					'font_headings' => array(
						'font-family' => 'futura-pt',
						'variant' => '600',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '-0.0125em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 600,
						'font-style' => 'normal'
					),
					'font_headings_size' => 'medium',
					'font_menu' => array(
						'font-family' => 'futura-pt',
						'variant' => '500',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 500,
						'font-style' => 'normal'
					),
					'font_primary' => array(
						'font-family' => 'futura-pt',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_secondary' => array(
						'font-family' => 'futura-pt',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.938rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_submenu' => array(
						'font-family' => 'futura-pt',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_title_block' => array(
						'font-family' => 'futura-pt',
						'variant' => '500',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'color' => '#a2b0bf',
						'font-backup' => '',
						'font-weight' => 500,
						'font-style' => 'normal'
					)
				),
				'mods_fallback' => array(
					'font_menu' => array(
						'font-size' => '0.938rem',
					),
				),
			),
			'design-flow' => array(
				'name' => 'Design Flow',
				'preview_image_url' => '/images/theme-demos/design-flow.jpg',
				'mods' => array(
					'archive_layout' => 'grid',
					'archive_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'archive_sidebar' => 'right',
					'category_featured_posts' => true,
					'category_featured_posts_exclude' => true,
					'category_subcategories' => true,
					'color_primary' => '#d197e6',
					'featured_posts' => true,
					'featured_posts_exclude' => true,
					'footer_featured_posts' => true,
					'footer_social_links_scheme' => 'bold-rounded',
					'header_social_links_scheme' => 'bold',
					'hero' => true,
					'hero_alignment' => 'right',
					'hero_background_color' => '#f5f5f5',
					'hero_background_image_outside' => false,
					'hero_background_image_position' => 'center center',
					'hero_height' => '600px',
					'hero_image_opacity' => 1.0,
					'hero_lead' => 'Find your design inspiration today.',
					'hero_search_form' => true,
					'hero_subscription_form' => false,
					'hero_title' => 'Design Flow',
					'home_pagination_type' => 'load-more',
					'home_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'home_sidebar' => 'right',
					'post_header_type' => 'standard',
					'post_subscribe' => true,
					'search_placeholder' => 'Input your search keywords',
					'sticky_sidebar_method' => 'stick-last'
				),
				'mods_typekit' => array(
					'font_headings' => array(
						'font-family' => 'sofia-pro',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '-0.0334em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_headings_size' => 'large',
					'font_menu' => array(
						'font-family' => 'sofia-pro',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.938rem',
						'letter-spacing' => '0rem',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_primary' => array(
						'font-family' => 'sofia-pro',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_secondary' => array(
						'font-family' => 'sofia-pro',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.938rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_submenu' => array(
						'font-family' => 'sofia-pro',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.938rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_title_block' => array(
						'font-family' => 'sofia-pro',
						'variant' => 'regular',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'color' => '#a2b0bf',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					)
				)
			),
			'startups-today' => array(
				'name' => 'Startups Today',
				'preview_image_url' => '/images/theme-demos/startups-today.jpg',
				'mods' => array(
					'archive_layout' => 'grid',
					'archive_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'archive_sidebar' => 'right',
					'category_featured_posts' => true,
					'category_featured_posts_exclude' => true,
					'category_subcategories' => true,
					'color_navbar_bg' => '#ed2a2a',
					'color_primary' => '#ed2a2a',
					'featured_categories' => true,
					'featured_categories_order' => 'DESC',
					'featured_categories_orderby' => 'count',
					'featured_posts' => true,
					'featured_posts_exclude' => true,
					'footer_featured_posts' => true,
					'footer_social_links_scheme' => 'bold',
					'header_social_links_scheme' => 'light-rounded',
					'hero' => false,
					'hero_background_color' => '#495254',
					'hero_image_opacity' => 0.7,
					'hero_lead' => 'Subscribe to our blog updates and instantly receive our best-selling book &laquo;10 Productivity Myths&raquo; in PDF for free.',
					'hero_search_form' => false,
					'hero_subscription_form' => true,
					'hero_title' => 'New Ventures Daily',
					'home_layout' => 'grid',
					'home_pagination_type' => 'load-more',
					'home_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'home_sidebar' => 'disabled',
					'post_header_type' => 'overlay',
					'post_subscribe' => true,
					'search_placeholder' => 'Input your search keywords',
					'sticky_sidebar_method' => 'stick-last'
				),
				'mods_typekit' => array(
					'font_headings' => array(
						'font-family' => 'circe',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '-0.025em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_headings_size' => 'small',
					'font_menu' => array(
						'font-family' => 'circe',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.75rem',
						'letter-spacing' => '.025em;',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_primary' => array(
						'font-family' => 'circe',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.75rem',
						'letter-spacing' => '0',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_secondary' => array(
						'font-family' => 'circe',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.813rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_submenu' => array(
						'font-family' => 'circe',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.938rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_title_block' => array(
						'font-family' => 'circe',
						'variant' => 'regular',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'color' => '#a2b0bf',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					)
				)
			),
			'cryptograph' => array(
				'name' => 'Cryptograph',
				'preview_image_url' => '/images/theme-demos/cryptograph.jpg',
				'mods' => array(
					'archive_layout' => 'grid',
					'archive_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'archive_sidebar' => 'right',
					'category_featured_posts' => true,
					'category_featured_posts_exclude' => true,
					'category_subcategories' => true,
					'color_footer_bg' => '#021d3a',
					'color_navbar_bg' => '#021d3a',
					'color_overlay' => 'rgba(2,29,58,0.54)',
					'color_primary' => '#4dcba3',
					'featured_categories' => true,
					'featured_categories_order' => 'DESC',
					'featured_categories_orderby' => 'count',
					'featured_categories_posts_per_page' => '1',
					'featured_posts' => false,
					'featured_posts_exclude' => true,
					'footer_featured_posts' => true,
					'footer_social_links_scheme' => 'light-rounded',
					'header_social_links_maximum' => '3',
					'header_social_links_scheme' => 'light',
					'hero' => true,
					'hero_background_color' => '#0dc386',
					'hero_background_image_outside' => true,
					'hero_background_image_position' => 'center center',
					'hero_image_opacity' => 1.0,
					'hero_lead' => 'Subscribe to our blog updates and instantly receive our PDF guide «Start Trading Cryptocurrency in 5 Days» for free.',
					'hero_search_form' => false,
					'hero_subscription_form' => true,
					'hero_title' => 'Free PDF Guide: How to Trade Cryptocurrency',
					'home_layout' => 'list',
					'home_more_button' => false,
					'home_pagination_type' => 'load-more',
					'home_post_meta' => array(
						0 => 'category',
						1 => 'shares',
						2 => 'views'
					),
					'home_sidebar' => 'right',
					'post_header_type' => 'overlay',
					'post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'comments',
						6 => 'reading_time'
					),
					'post_subscribe' => true,
					'search_placeholder' => 'Input your search keywords',
					'sticky_sidebar_method' => 'stick-last'
				),
				'mods_typekit' => array(
					'font_headings' => array(
						'font-family' => 'runda',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '-0.0125em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_headings_size' => 'medium',
					'font_menu' => array(
						'font-family' => 'runda',
						'variant' => '500',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 500,
						'font-style' => 'normal'
					),
					'font_primary' => array(
						'font-family' => 'runda',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '-.0125em;',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_secondary' => array(
						'font-family' => 'runda',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.938rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_submenu' => array(
						'font-family' => 'runda',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.875rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_title_block' => array(
						'font-family' => 'runda',
						'variant' => 'regular',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'color' => '#a2b0bf',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					)
				)
			),
			'hanna-janssen' => array(
				'name' => 'Hanna Janssen',
				'preview_image_url' => '/images/theme-demos/hanna-janssen.jpg',
				'mods' => array(
					'archive_layout' => 'grid',
					'archive_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'archive_sidebar' => 'right',
					'category_featured_posts' => true,
					'category_featured_posts_exclude' => true,
					'category_subcategories' => true,
					'color_overlay' => 'rgba(78,94,104,0.41)',
					'color_primary' => '#fba1b2',
					'featured_posts' => false,
					'featured_posts_exclude' => true,
					'footer_featured_posts' => true,
					'footer_social_links_scheme' => 'bold',
					'header_social_links_scheme' => 'bold',
					'hero' => true,
					'hero_alignment' => 'right',
					'hero_background_color' => '#f8f8f8',
					'hero_background_image_outside' => true,
					'hero_background_image_position' => 'bottom right',
					'hero_height' => '600px',
					'hero_image_opacity' => 1.0,
					'hero_lead' => 'Subscribe to my blog updates and instantly receive my easy-to-follow PDF-guide <strong>«Change Your Habits and Become a Better Version of Yourself»</strong> for <span class="pk-badge pk-badge-primary">free</span>.',
					'hero_search_form' => false,
					'hero_subscription_form' => true,
					'hero_title' => '',
					'home_layout' => 'full-grid',
					'home_more_button' => false,
					'home_pagination_type' => 'load-more',
					'home_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'home_sidebar' => 'right',
					'post_header_type' => 'small',
					'post_sidebar' => 'disabled',
					'post_subscribe' => true,
					'related_layout' => 'grid',
					'related_number' => '9',
					'search_placeholder' => 'Input your search keywords',
					'sticky_sidebar_method' => 'stick-last'
				),
				'mods_typekit' => array(
					'font_base' => array(
						'font-family' => 'proxima-nova',
						'variant' => '300',
						'subsets' => array(
							'latin'
						),
						'font-size' => '1rem',
						'letter-spacing' => '0',
						'font-backup' => '',
						'font-weight' => 300,
						'font-style' => 'normal'
					),
					'font_headings' => array(
						'font-family' => 'proxima-nova',
						'variant' => '300',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '-0.0125em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 300,
						'font-style' => 'normal'
					),
					'font_headings_size' => 'large',
					'font_menu' => array(
						'font-family' => 'proxima-nova',
						'variant' => 'regular',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.75rem',
						'letter-spacing' => '0.0625em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_primary' => array(
						'font-family' => 'proxima-nova',
						'variant' => 'regular',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.0625em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_secondary' => array(
						'font-family' => 'proxima-nova',
						'subsets' => array(
							'latin'
						),
						'variant' => '300',
						'font-size' => '0.813rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 300,
						'font-style' => 'normal'
					),
					'font_submenu' => array(
						'font-family' => 'proxima-nova',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.75rem',
						'letter-spacing' => '0',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_title_block' => array(
						'font-family' => 'proxima-nova',
						'variant' => 'regular',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'color' => '#a2b0bf',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					)
				)
			),
			'tropical-adventures' => array(
				'name' => 'Tropical Adventures',
				'preview_image_url' => '/images/theme-demos/tropical-adventures.jpg',
				'mods' => array(
					'archive_layout' => 'grid',
					'archive_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'archive_sidebar' => 'right',
					'category_featured_posts' => true,
					'category_featured_posts_exclude' => true,
					'category_subcategories' => true,
					'color_footer_bg' => '#0a0a0a',
					'color_navbar_bg' => '#0a0a0a',
					'color_primary' => '#01ca6c',
					'featured_posts' => false,
					'featured_posts_exclude' => true,
					'footer_featured_posts' => true,
					'footer_social_links_scheme' => 'bold',
					'header_social_links_maximum' => '2',
					'header_social_links_scheme' => 'light-rounded',
					'hero' => true,
					'hero_alignment' => 'center',
					'hero_background_color' => '#0a0a0a',
					'hero_background_image_position' => 'center center',
					'hero_height' => '600px',
					'hero_image_opacity' => 0.6,
					'hero_lead' => 'Find your next destination and travel ideas.',
					'hero_search_form' => true,
					'hero_subscription_form' => false,
					'hero_title' => '',
					'home_layout' => 'grid',
					'home_pagination_type' => 'infinite',
					'home_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'home_sidebar' => 'disabled',
					'post_header_type' => 'overlay',
					'post_subscribe' => true,
					'related_layout' => 'grid',
					'related_number' => '4',
					'search_placeholder' => 'Input your search keywords',
					'sticky_sidebar_method' => 'stick-last'
				),
				'mods_typekit' => array(
					'font_base' => array(
						'font-family' => 'europa',
						'variant' => 'regular',
						'subsets' => array(
							'latin'
						),
						'font-size' => '.875rem',
						'letter-spacing' => '0',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_headings' => array(
						'font-family' => 'europa',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '-0.0125em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_headings_size' => 'medium',
					'font_menu' => array(
						'font-family' => 'europa',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.875rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_primary' => array(
						'font-family' => 'europa',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_secondary' => array(
						'font-family' => 'europa',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.813rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_submenu' => array(
						'font-family' => 'europa',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.875rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_title_block' => array(
						'font-family' => 'europa',
						'variant' => '300',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'color' => '#0a0808',
						'font-backup' => '',
						'font-weight' => 300,
						'font-style' => 'normal'
					)
				)
			),
			'the-challenge' => array(
				'name' => 'The Challenge',
				'preview_image_url' => '/images/theme-demos/the-challenge.jpg',
				'mods' => array(
					'archive_layout' => 'grid',
					'archive_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'archive_sidebar' => 'right',
					'category_featured_posts' => true,
					'category_featured_posts_exclude' => true,
					'category_subcategories' => true,
					'color_primary' => '#f12c2c',
					'featured_posts' => false,
					'featured_posts_exclude' => true,
					'font_base' => array(
						'font-family' => 'Lato',
						'variant' => 'regular',
						'subsets' => array(
							'latin'
						),
						'font-size' => '1rem',
						'letter-spacing' => '0',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'footer_featured_posts' => true,
					'footer_social_links_scheme' => 'bold',
					'header_social_links_scheme' => 'light-rounded',
					'hero' => true,
					'hero_alignment' => 'center',
					'hero_background_color' => '#242728',
					'hero_height' => '600px',
					'hero_image_opacity' => 0.6,
					'hero_lead' => 'Subscribe to our blog updates and instantly receive our 30 day workout plan in PDF for <span class="pk-badge pk-badge-primary">free</span>.',
					'hero_search_form' => false,
					'hero_subscription_form' => true,
					'hero_title' => '',
					'home_layout' => 'list',
					'home_pagination_type' => 'load-more',
					'home_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'home_sidebar' => 'right',
					'miscellaneous_border_radius' => '30px',
					'post_header_type' => 'overlay',
					'post_subscribe' => true,
					'search_placeholder' => 'Input your search keywords',
					'sticky_sidebar_method' => 'stick-last'
				),
				'mods_typekit' => array(
					'font_headings' => array(
						'font-family' => 'stolzl',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '-0.0125em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_headings_size' => 'small',
					'font_menu' => array(
						'font-family' => 'stolzl',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.875rem',
						'letter-spacing' => '-.0125em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_primary' => array(
						'font-family' => 'stolzl',
						'variant' => 'regular',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.75rem',
						'letter-spacing' => '0.083em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_secondary' => array(
						'font-family' => 'stolzl',
						'subsets' => array(
							'latin'
						),
						'variant' => '300',
						'font-size' => '0.75rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 300,
						'font-style' => 'normal'
					),
					'font_submenu' => array(
						'font-family' => 'stolzl',
						'subsets' => array(
							'latin'
						),
						'variant' => '300',
						'font-size' => '0.75rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 300,
						'font-style' => 'normal'
					),
					'font_title_block' => array(
						'font-family' => 'stolzl',
						'variant' => '300',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'color' => '#a2b0bf',
						'font-backup' => '',
						'font-weight' => 300,
						'font-style' => 'normal'
					)
				)
			),
			'allen-murphy' => array(
				'name' => 'Allen Murphy',
				'preview_image_url' => '/images/theme-demos/allen-murphy.jpg',
				'mods' => array(
					'archive_layout' => 'grid',
					'archive_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'archive_sidebar' => 'right',
					'category_featured_posts' => true,
					'category_featured_posts_exclude' => true,
					'category_subcategories' => true,
					'color_primary' => '#383838',
					'featured_posts' => false,
					'featured_posts_exclude' => true,
					'font_base' => array(
						'font-family' => 'Lora',
						'variant' => 'regular',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.938rem',
						'letter-spacing' => '0',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_headings' => array(
						'font-family' => 'Playfair Display',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_headings_size' => 'medium',
					'footer_featured_posts' => true,
					'footer_social_links_scheme' => 'bold',
					'header_social_links_maximum' => '3',
					'header_social_links_scheme' => 'bold',
					'hero' => true,
					'hero_alignment' => 'left',
					'hero_background_color' => '#f7f8fc',
					'hero_background_image_outside' => true,
					'hero_image_opacity' => 1.0,
					'hero_lead' => 'Subscribe to my blog updates and instantly download my best-selling book «The Downtown Stories» for <span class="pk-badge pk-badge-primary">free</span>.',
					'hero_search_form' => false,
					'hero_subscription_form' => true,
					'hero_title' => 'The Downtown Stories <em style="color:#a0a0a0;font-weight: 400">by</em><br>Allen Murphy',
					'home_layout' => 'list',
					'home_pagination_type' => 'load-more',
					'home_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'home_sidebar' => 'disabled',
					'miscellaneous_border_radius' => '0',
					'post_header_type' => 'overlay',
					'post_subscribe' => true,
					'search_placeholder' => 'Input your search keywords',
					'sticky_sidebar_method' => 'stick-last'
				),
				'mods_typekit' => array(
					'font_menu' => array(
						'font-family' => 'futura-pt',
						'variant' => '600',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.875rem',
						'letter-spacing' => '0.0769em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 600,
						'font-style' => 'normal'
					),
					'font_primary' => array(
						'font-family' => 'futura-pt',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.75rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_secondary' => array(
						'font-family' => 'futura-pt',
						'subsets' => array(
							'latin'
						),
						'variant' => '500',
						'font-size' => '0.938rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 500,
						'font-style' => 'normal'
					),
					'font_submenu' => array(
						'font-family' => 'futura-pt',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_title_block' => array(
						'font-family' => 'futura-pt',
						'variant' => '500',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'color' => '#a2b0bf',
						'font-backup' => '',
						'font-weight' => 500,
						'font-style' => 'normal'
					)
				)
			),
			'mia-lovecraft' => array(
				'name' => 'Mia Lovecraft',
				'preview_image_url' => '/images/theme-demos/mia-lovecraft.jpg',
				'mods' => array(
					'archive_layout' => 'grid',
					'archive_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'archive_sidebar' => 'right',
					'category_featured_posts' => true,
					'category_featured_posts_exclude' => true,
					'category_subcategories' => true,
					'color_footer_bg' => '#1f2727',
					'color_primary' => '#c09c62',
					'featured_posts' => true,
					'featured_posts_exclude' => true,
					'font_base' => array(
						'font-family' => 'Barlow',
						'variant' => 'regular',
						'subsets' => array(
							'latin'
						),
						'font-size' => '1rem',
						'letter-spacing' => '0',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_headings' => array(
						'font-family' => 'Barlow',
						'variant' => '600',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '-0.0125em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 600,
						'font-style' => 'normal'
					),
					'font_headings_size' => 'small',
					'font_menu' => array(
						'font-family' => 'Barlow Semi Condensed',
						'variant' => '600',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 600,
						'font-style' => 'normal'
					),
					'font_primary' => array(
						'font-family' => 'Barlow',
						'variant' => '600',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 600,
						'font-style' => 'normal'
					),
					'font_secondary' => array(
						'font-family' => 'Barlow Semi Condensed',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.938rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_submenu' => array(
						'font-family' => 'Barlow',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.938rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_title_block' => array(
						'font-family' => 'Barlow',
						'variant' => '500',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'color' => '#a2b0bf',
						'font-backup' => '',
						'font-weight' => 500,
						'font-style' => 'normal'
					),
					'footer_featured_posts' => true,
					'footer_social_links_scheme' => 'bold',
					'header_social_links_scheme' => 'light',
					'hero' => true,
					'hero_alignment' => 'left',
					'hero_background_color' => '#1f2727',
					'hero_background_image_outside' => true,
					'hero_height' => '400px',
					'hero_image_opacity' => 1.0,
					'hero_lead' => 'Subscribe to my blog updates  to get a daily dose of style, food and travel. ',
					'hero_search_form' => false,
					'hero_subscription_form' => true,
					'hero_title' => 'Elegant style, finger-licking food, and traveling experiences',
					'home_layout' => 'full-grid',
					'home_pagination_type' => 'load-more',
					'home_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'home_sidebar' => 'right',
					'miscellaneous_border_radius' => '0',
					'post_header_type' => 'overlay',
					'post_subscribe' => true,
					'search_placeholder' => 'Input your search keywords',
					'sticky_sidebar_method' => 'stick-last'
				)
			),
			'sports24' => array(
				'name' => 'Sports24',
				'preview_image_url' => '/images/theme-demos/sports24.jpg',
				'mods' => array(
					'archive_layout' => 'grid',
					'archive_more_button' => false,
					'archive_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'archive_sidebar' => 'right',
					'category_featured_posts' => true,
					'category_featured_posts_exclude' => true,
					'category_subcategories' => true,
					'color_footer_bg' => '#0a0a0a',
					'color_navbar_bg' => '#0a0a0a',
					'color_primary' => '#0adea9',
					'featured_categories' => true,
					'featured_categories_order' => 'DESC',
					'featured_categories_orderby' => 'count',
					'featured_posts' => true,
					'featured_posts_exclude' => true,
					'footer_featured_posts' => true,
					'footer_social_links_scheme' => 'bold-rounded',
					'footer_title' => 'Sports <span class="pk-badge pk-badge-primary">24</span>',
					'header_social_links_scheme' => 'bold-rounded',
					'hero' => false,
					'hero_background_color' => '#495254',
					'hero_image_opacity' => 0.7,
					'hero_lead' => 'Subscribe to our blog updates and instantly receive our best-selling book &laquo;10 Productivity Myths&raquo; in PDF for free.',
					'hero_search_form' => false,
					'hero_subscription_form' => true,
					'hero_title' => 'Self-Made Entrepreneurs',
					'home_more_button' => false,
					'home_pagination_type' => 'infinite',
					'home_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'home_sidebar' => 'right',
					'miscellaneous_border_radius' => '30px',
					'post_header_type' => 'overlay',
					'post_load_nextpost' => true,
					'post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'shares',
						3 => 'views',
						4 => 'comments',
						5 => 'reading_time'
					),
					'post_subscribe' => true,
					'related_layout' => 'grid',
					'search_placeholder' => 'Input your search keywords',
					'sticky_sidebar_method' => 'stick-last'
				),
				'mods_typekit' => array(
					'font_headings' => array(
						'font-family' => 'aktiv-grotesk',
						'variant' => '800',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '-0.0125em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 800,
						'font-style' => 'normal'
					),
					'font_headings_size' => 'large',
					'font_menu' => array(
						'font-family' => 'aktiv-grotesk',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.875rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_primary' => array(
						'font-family' => 'aktiv-grotesk',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_secondary' => array(
						'font-family' => 'aktiv-grotesk',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.813rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_submenu' => array(
						'font-family' => 'aktiv-grotesk',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.813rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_title_block' => array(
						'font-family' => 'aktiv-grotesk',
						'variant' => 'regular',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'color' => '#a2b0bf',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					)
				)
			),
			'rocketcloud' => array(
				'name' => 'RocketCloud',
				'preview_image_url' => '/images/theme-demos/rocketcloud.jpg',
				'mods' => array(
					'archive_layout' => 'grid',
					'archive_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'archive_sidebar' => 'right',
					'category_featured_posts' => true,
					'category_featured_posts_exclude' => true,
					'category_subcategories' => true,
					'color_footer_bg' => '#ffffff',
					'color_primary' => '#165fde',
					'featured_posts' => false,
					'featured_posts_exclude' => true,
					'footer_featured_posts' => true,
					'footer_social_links_scheme' => 'bold',
					'header_social_links_scheme' => 'bold',
					'hero' => true,
					'hero_background_color' => '#1c5ad8',
					'hero_background_image_outside' => false,
					'hero_image_opacity' => 1.0,
					'hero_lead' => 'Subscribe to our blog updates and get early<br>access to our public beta for <span class="pk-badge pk-badge-primary">Free</span>.',
					'hero_search_form' => false,
					'hero_subscription_form' => true,
					'hero_title' => 'Advanced Decentralized Data-Driven Process',
					'home_layout' => 'grid',
					'home_more_button' => false,
					'home_pagination_type' => 'load-more',
					'home_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'home_sidebar' => 'disabled',
					'post_header_type' => 'standard',
					'post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'shares',
						3 => 'views',
						4 => 'comments',
						5 => 'reading_time'
					),
					'post_subscribe' => true,
					'search_placeholder' => 'Input your search keywords',
					'sticky_sidebar_method' => 'stick-last',
					'woocommerce_header_hide_icon' => true
				),
				'mods_typekit' => array(
					'font_headings' => array(
						'font-family' => 'europa',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '-0.025em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_headings_size' => 'large',
					'font_menu' => array(
						'font-family' => 'europa',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.75rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_primary' => array(
						'font-family' => 'europa',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.688rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_secondary' => array(
						'font-family' => 'europa',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.75rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_submenu' => array(
						'font-family' => 'europa',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.875rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_title_block' => array(
						'font-family' => 'europa',
						'variant' => 'regular',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'color' => '#a2b0bf',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					)
				)
			),
			'bueromag' => array(
				'name' => 'Buero',
				'preview_image_url' => '/images/theme-demos/bueromag.jpg',
				'mods' => array(
					'archive_layout' => 'grid',
					'archive_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'archive_sidebar' => 'right',
					'category_featured_posts' => true,
					'category_featured_posts_exclude' => true,
					'category_subcategories' => true,
					'color_footer_bg' => '#242c2c',
					'color_overlay' => 'rgba(38,48,48,0.22)',
					'color_primary' => '#677983',
					'featured_categories' => false,
					'featured_categories_columns' => '3',
					'featured_categories_number' => '3',
					'featured_categories_order' => 'DESC',
					'featured_categories_orderby' => 'count',
					'featured_categories_posts_per_page' => '1',
					'featured_posts' => true,
					'featured_posts_exclude' => true,
					'footer_featured_posts' => true,
					'footer_social_links_scheme' => 'light',
					'footer_title' => 'Buero',
					'header_social_links_scheme' => 'light',
					'hero' => false,
					'hero_background_color' => '#495254',
					'hero_image_opacity' => 0.7,
					'hero_lead' => 'Subscribe to our blog updates and instantly receive our best-selling book &laquo;10 Productivity Myths&raquo; in PDF for free.',
					'hero_search_form' => false,
					'hero_subscription_form' => true,
					'hero_title' => 'Self-Made Entrepreneurs',
					'home_layout' => 'masonry',
					'home_pagination_type' => 'load-more',
					'home_post_meta' => array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
						5 => 'reading_time'
					),
					'home_sidebar' => 'disabled',
					'miscellaneous_border_radius' => '0',
					'post_header_type' => 'overlay',
					'post_subscribe' => true,
					'search_placeholder' => 'Input your search keywords',
					'sticky_sidebar_method' => 'stick-last'
				),
				'mods_typekit' => array(
					'font_base' => array(
						'font-family' => 'Lato',
						'variant' => 'regular',
						'subsets' => array(
							'latin'
						),
						'font-size' => '.875rem',
						'letter-spacing' => '0',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_headings' => array(
						'font-family' => 'brandon-grotesque',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'letter-spacing' => '0.0125em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_headings_size' => 'small',
					'font_menu' => array(
						'font-family' => 'brandon-grotesque',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.0769em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_primary' => array(
						'font-family' => 'brandon-grotesque',
						'variant' => '700',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.75rem',
						'letter-spacing' => '0.083em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal'
					),
					'font_secondary' => array(
						'font-family' => 'brandon-grotesque',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'font-size' => '0.813rem',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_submenu' => array(
						'font-family' => 'brandon-grotesque',
						'subsets' => array(
							'latin'
						),
						'variant' => 'regular',
						'letter-spacing' => '0',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					),
					'font_title_block' => array(
						'font-family' => 'brandon-grotesque',
						'variant' => 'regular',
						'subsets' => array(
							'latin'
						),
						'font-size' => '0.813rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'color' => '#a2b0bf',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal'
					)
				)
			)
		)
	);
	return $demos;
}
add_filter( 'csco_theme_demos', 'csco_theme_demos' );
