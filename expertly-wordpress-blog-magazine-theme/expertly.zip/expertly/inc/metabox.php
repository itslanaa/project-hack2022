<?php
/**
 * Adding Custom Meta Boxes.
 *
 * @package Expertly
 */

/**
 * Check display metabox layout options
 */
function csco_mb_display_layout_options() {
	// Check Coming Soon Page.
	if ( csco_powerkit_module_enabled( 'coming_soon' ) && powerkit_coming_soon_status() ) {

		$page_id = get_option( 'powerkit_coming_soon_page' );

		if ( (int) get_the_ID() === (int) $page_id ) {
			return;
		}
	}

	return true;
}

/**
 * ==================================
 * Layout Options
 * ==================================
 */

/**
 * Add new meta box
 */
function csco_mb_layout_options() {
	if ( ! csco_mb_display_layout_options() ) {
		return;
	}

	$function = sprintf( 'add_meta_%s', 'box' );

	$function( 'csco_mb_layout_options', esc_html__( 'Layout Options', 'expertly' ), 'csco_mb_layout_options_callback', array( 'post', 'page', 'product' ), 'side' );
}
add_action( sprintf( 'add_meta_%s', 'boxes' ), 'csco_mb_layout_options' );

/**
 * Callback meta box
 *
 * @param object $post The post object.
 */
function csco_mb_layout_options_callback( $post ) {

	$page_static = array();

	// Add pages static.
	$page_static[] = get_option( 'page_on_front' );
	$page_static[] = get_option( 'page_for_posts' );

	wp_nonce_field( 'layout_options', 'csco_mb_layout_options' );

	$sidebar            = get_post_meta( $post->ID, 'csco_singular_sidebar', true );
	$page_header_type   = get_post_meta( $post->ID, 'csco_page_header_type', true );
	$page_load_nextpost = get_post_meta( $post->ID, 'csco_page_load_nextpost', true );

	// Set Default.
	$sidebar            = $sidebar ? $sidebar : 'default';
	$page_header_type   = $page_header_type ? $page_header_type : 'default';
	$page_load_nextpost = $page_load_nextpost ? $page_load_nextpost : 'default';
	?>
		<h4><?php esc_html_e( 'Sidebar', 'expertly' ); ?></h4>
		<select name="csco_singular_sidebar" id="csco_singular_sidebar" style="box-sizing: border-box;" class="regular-text">
			<option value="default" <?php selected( 'default', $sidebar ); ?>> <?php esc_html_e( 'Default', 'expertly' ); ?></option>
			<option value="right" <?php selected( 'right', $sidebar ); ?>> <?php esc_html_e( 'Right Sidebar', 'expertly' ); ?></option>
			<option value="left" <?php selected( 'left', $sidebar ); ?>> <?php esc_html_e( 'Left Sidebar', 'expertly' ); ?></option>
			<option value="disabled" <?php selected( 'disabled', $sidebar ); ?>> <?php esc_html_e( 'No Sidebar', 'expertly' ); ?></option>
		</select>

		<?php if ( ! in_array( (string) $post->ID, $page_static, true ) || 'posts' === get_option( 'show_on_front', 'posts' ) ) { ?>

			<?php if ( 'post' === $post->post_type || 'page' === $post->post_type ) { ?>
				<h4><?php esc_html_e( 'Page Header Type', 'expertly' ); ?></h4>
				<select name="csco_page_header_type" id="csco_page_header_type" style="box-sizing: border-box;" class="regular-text">
					<option value="default" <?php selected( 'default', $page_header_type ); ?>> <?php esc_html_e( 'Default', 'expertly' ); ?></option>
					<option value="none" <?php selected( 'none', $page_header_type ); ?>> <?php esc_html_e( 'None', 'expertly' ); ?></option>
					<option value="standard" <?php selected( 'standard', $page_header_type ); ?>> <?php esc_html_e( 'Standard', 'expertly' ); ?></option>
					<option value="small" <?php selected( 'small', $page_header_type ); ?>> <?php esc_html_e( 'Small', 'expertly' ); ?></option>
					<option value="overlay" <?php selected( 'overlay', $page_header_type ); ?>> <?php esc_html_e( 'Overlay', 'expertly' ); ?></option>
					<option value="title" <?php selected( 'title', $page_header_type ); ?>> <?php esc_html_e( 'Page Title Only', 'expertly' ); ?></option>
				</select>
			<?php } ?>

			<?php if ( 'post' === $post->post_type ) { ?>
				<h4><?php esc_html_e( 'Auto Load Next Post', 'expertly' ); ?></h4>
				<select name="csco_page_load_nextpost" id="csco_page_load_nextpost" style="box-sizing: border-box;" class="regular-text">
					<option value="default" <?php selected( 'default', $page_load_nextpost ); ?>> <?php esc_html_e( 'Default', 'expertly' ); ?></option>
					<option value="enabled" <?php selected( 'enabled', $page_load_nextpost ); ?>> <?php esc_html_e( 'Enabled', 'expertly' ); ?></option>
					<option value="disabled" <?php selected( 'disabled', $page_load_nextpost ); ?>> <?php esc_html_e( 'Disabled', 'expertly' ); ?></option>
				</select>
			<?php } ?>

		<?php } ?>
	<?php
}

/**
 * Save meta box
 *
 * @param int $post_id The post id.
 */
function csco_mb_layout_options_save( $post_id ) {

	// Bail if we're doing an auto save.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	// if our nonce isn't there, or we can't verify it, bail.
	if ( ! isset( $_POST['csco_mb_layout_options'] ) || ! wp_verify_nonce( $_POST['csco_mb_layout_options'], 'layout_options' ) ) { // Input var ok; sanitization ok.
		return;
	}

	if ( isset( $_POST['csco_singular_sidebar'] ) ) { // Input var ok; sanitization ok.
		$sidebar = sanitize_text_field( $_POST['csco_singular_sidebar'] ); // Input var ok; sanitization ok.

		update_post_meta( $post_id, 'csco_singular_sidebar', $sidebar );
	}

	if ( isset( $_POST['csco_page_header_type'] ) ) { // Input var ok; sanitization ok.
		$page_header_type = sanitize_text_field( $_POST['csco_page_header_type'] ); // Input var ok; sanitization ok.

		update_post_meta( $post_id, 'csco_page_header_type', $page_header_type );
	}

	if ( isset( $_POST['csco_page_load_nextpost'] ) ) { // Input var ok; sanitization ok.
		$page_load_nextpost = sanitize_text_field( $_POST['csco_page_load_nextpost'] ); // Input var ok; sanitization ok.

		update_post_meta( $post_id, 'csco_page_load_nextpost', $page_load_nextpost );
	}
}
add_action( 'save_post', 'csco_mb_layout_options_save' );
