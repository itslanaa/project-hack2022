<?php
/**
 * These functions are used to load template parts (partials) or actions when used within action hooks,
 * and they probably should never be updated or modified.
 *
 * @package Expertly
 */

if ( ! function_exists( 'csco_singular_post_type_before' ) ) {
	/**
	 * Add Before Singular Hooks for specific post type.
	 */
	function csco_singular_post_type_before() {
		if ( 'post' === get_post_type() ) {
			do_action( 'csco_post_content_before' );
		}
		if ( 'page' === get_post_type() ) {
			do_action( 'csco_page_content_before' );
		}
	}
}

if ( ! function_exists( 'csco_singular_post_type_after' ) ) {
	/**
	 * Add After Singular Hooks for specific post type.
	 */
	function csco_singular_post_type_after() {
		if ( 'post' === get_post_type() ) {
			do_action( 'csco_post_content_after' );
		}
		if ( 'page' === get_post_type() ) {
			do_action( 'csco_page_content_after' );
		}
	}
}

if ( ! function_exists( 'csco_singular_post_type_start' ) ) {
	/**
	 * Add Start Singular Hooks for specific post type.
	 */
	function csco_singular_post_type_start() {
		if ( 'post' === get_post_type() ) {
			do_action( 'csco_post_content_start' );
		}
		if ( 'page' === get_post_type() ) {
			do_action( 'csco_page_content_start' );
		}
	}
}

if ( ! function_exists( 'csco_singular_post_type_end' ) ) {
	/**
	 * Add End Singular Hooks for specific post type.
	 */
	function csco_singular_post_type_end() {
		if ( 'post' === get_post_type() ) {
			do_action( 'csco_post_content_end' );
		}
		if ( 'page' === get_post_type() ) {
			do_action( 'csco_page_content_end' );
		}
	}
}

if ( ! function_exists( 'csco_offcanvas' ) ) {
	/**
	 * Off-canvas
	 */
	function csco_offcanvas() {
		get_template_part( 'template-parts/offcanvas' );
	}
}

if ( ! function_exists( 'csco_header_social_links' ) ) {
	/**
	 * Header Social Links
	 */
	function csco_header_social_links() {

		if ( ! get_theme_mod( 'header_social_links', false ) ) {
			return;
		}

		if ( ! csco_powerkit_module_enabled( 'social_links' ) ) {
			return;
		}

		$scheme  = get_theme_mod( 'header_social_links_scheme', 'light' );
		$maximum = get_theme_mod( 'header_social_links_maximum', 3 );
		$counts  = get_theme_mod( 'header_social_links_counts', true );

		powerkit_social_links( false, false, $counts, 'nav', $scheme, 'mixed', $maximum );

	}
}

if ( ! function_exists( 'csco_header_search_button' ) ) {
	/**
	 * Header Social Links
	 */
	function csco_header_search_button() {
		if ( ! get_theme_mod( 'header_search_button', true ) ) {
			return;
		}
		?>
		<button type="button" class="toggle-search">
			<i class="cs-icon cs-icon-search"></i>
		</button>
		<?php
	}
}

if ( ! function_exists( 'csco_single_author' ) ) {
	/**
	 * Post Author
	 */
	function csco_single_author() {
		if ( ! is_singular( 'post' ) ) {
			return;
		}
		if ( ! in_array( 'author', (array) get_theme_mod( 'post_meta', array( 'author' ) ), true ) ) {
			return;
		}
		get_template_part( 'template-parts/post-author' );
	}
}

if ( ! function_exists( 'csco_single_subscribe' ) ) {
	/**
	 * Post Subscribe
	 */
	function csco_single_subscribe() {
		if ( false === get_theme_mod( 'post_subscribe', false ) ) {
			return;
		}

		if ( csco_powerkit_module_enabled( 'opt_in_forms' ) ) {

			if ( ! is_singular( 'post' ) ) {
				return;
			}

			get_template_part( 'template-parts/post-subscribe' );
		}
	}
}

if ( ! function_exists( 'csco_comments' ) ) {
	/**
	 * Post / Page Comments
	 */
	function csco_comments() {
		if ( post_password_required() ) {
			return;
		}

		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
	}
}

if ( ! function_exists( 'csco_site_search' ) ) {
	/**
	 * Site Search
	 */
	function csco_site_search() {
		get_template_part( 'template-parts/site-search' );
	}
}

if ( ! function_exists( 'csco_page_header' ) ) {
	/**
	 * Page Header
	 */
	function csco_page_header() {
		if ( ! ( is_archive() || is_search() || is_404() ) ) {
			return;
		}
		get_template_part( 'template-parts/page-header' );
	}
}

if ( ! function_exists( 'csco_breadcrumbs' ) ) {
	/**
	 * Yoast SEO Breadcrumbs
	 */
	function csco_breadcrumbs() {
		if ( ! function_exists( 'yoast_breadcrumb' ) || is_front_page() || is_category() ) {
			return;
		}
		yoast_breadcrumb( '<section class="cs-breadcrumbs" id="breadcrumbs">', '</section>' );
	}
}

if ( ! function_exists( 'csco_subcategories' ) ) {
	/**
	 * Subcategories
	 */
	function csco_subcategories() {

		if ( false === get_theme_mod( 'category_subcategories', false ) ) {
			return;
		}

		if ( ! is_category() ) {
			return;
		}

		$args = apply_filters( 'csco_subcategories_args', array(
			'parent' => get_query_var( 'cat' ),
		) );

		$categories = get_categories( $args );

		if ( $categories ) {
		?>
		<section class="subcategories">
			<?php $tag = apply_filters( 'csco_section_title_tag', 'h5' ); ?>
			<<?php echo esc_html( $tag ); ?> class="title-block"><?php esc_html_e( 'Subcategories', 'expertly' ); ?></<?php echo esc_html( $tag ); ?>>
			<ul class="cs-nav cs-nav-pills">
			<?php
			foreach ( $categories as $category ) {
				// Translators: category name.
				$title = sprintf( esc_html__( 'View all posts in %s', 'expertly' ), $category->name );
				$link  = get_category_link( $category->term_id )
				?>
					<li class="cs-nav-item">
						<a class="cs-nav-link" data-toggle="pill" href="<?php echo esc_url( $link ); ?>" title="<?php echo esc_attr( $title ); ?>">
							<?php echo esc_html( $category->name ); ?>
						</a>
					</li>
				<?php
			}
			?>
			</ul>
		</section>
		<?php
		}
	}
}

if ( ! function_exists( 'csco_homepage_hero' ) ) {
	/**
	 * Homepage Hero Section
	 */
	function csco_homepage_hero() {

		if ( false === get_theme_mod( 'hero', false ) ) {
			return;
		}

		if ( ! ( is_front_page() || is_home() ) ) {
			return;
		}

		$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

		if ( 1 !== $paged ) {
			return;
		}

		if ( is_front_page() && 'page' === get_option( 'show_on_front', 'posts' ) && 'home' === get_theme_mod( 'hero_location', 'front_page' ) ) {
			return;
		}

		if ( is_home() && 'page' === get_option( 'show_on_front', 'posts' ) && 'front_page' === get_theme_mod( 'hero_location', 'front_page' ) ) {
			return;
		}

		get_template_part( 'template-parts/homepage-hero' );
	}
}

if ( ! function_exists( 'csco_homepage_posts' ) ) {
	/**
	 * Homepage Posts Section
	 */
	function csco_homepage_posts() {

		if ( false === get_theme_mod( 'featured_posts', false ) ) {
			return;
		}

		if ( ! ( is_front_page() || is_home() ) ) {
			return;
		}

		$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

		if ( 1 !== $paged ) {
			return;
		}

		if ( is_front_page() && 'page' === get_option( 'show_on_front', 'posts' ) && 'home' === get_theme_mod( 'featured_posts_location', 'front_page' ) ) {
			return;
		}

		if ( is_home() && 'page' === get_option( 'show_on_front', 'posts' ) && 'front_page' === get_theme_mod( 'featured_posts_location', 'front_page' ) ) {
			return;
		}

		get_template_part( 'template-parts/homepage-posts' );
	}
}

if ( ! function_exists( 'csco_category_posts' ) ) {
	/**
	 * Category Posts Section
	 */
	function csco_category_posts() {

		if ( false === get_theme_mod( 'category_featured_posts', false ) ) {
			return;
		}

		if ( ! is_category() ) {
			return;
		}

		$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

		if ( 1 !== $paged ) {
			return;
		}

		get_template_part( 'template-parts/category-posts' );
	}
}

if ( ! function_exists( 'csco_footer_posts' ) ) {
	/**
	 * Footer Posts Section
	 */
	function csco_footer_posts() {

		if ( false === get_theme_mod( 'footer_featured_posts', false ) ) {
			return;
		}

		get_template_part( 'template-parts/footer-posts' );
	}
}

if ( ! function_exists( 'csco_homepage_categories' ) ) {
	/**
	 * Homepage Categories Section
	 */
	function csco_homepage_categories() {

		if ( false === get_theme_mod( 'featured_categories', false ) ) {
			return;
		}

		if ( ! ( is_front_page() || is_home() ) ) {
			return;
		}

		$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

		if ( 1 !== $paged ) {
			return;
		}

		if ( is_front_page() && 'page' === get_option( 'show_on_front', 'posts' ) && 'home' === get_theme_mod( 'featured_categories_location', 'front_page' ) ) {
			return;
		}

		if ( is_home() && 'page' === get_option( 'show_on_front', 'posts' ) && 'front_page' === get_theme_mod( 'featured_categories_location', 'front_page' ) ) {
			return;
		}

		get_template_part( 'template-parts/homepage-categories' );
	}
}

if ( ! function_exists( 'csco_related_posts' ) ) {
	/**
	 * Related Posts
	 */
	function csco_related_posts() {
		if ( ! is_singular( 'post' ) ) {
			return;
		}
		if ( false === get_theme_mod( 'related', true ) ) {
			return;
		}
		get_template_part( 'template-parts/related-posts' );
	}
}

if ( ! function_exists( 'csco_meet_team' ) ) {
	/**
	 * Meet Team
	 */
	function csco_meet_team() {
		if ( is_page_template( 'template-meet-team.php' ) ) {
			get_template_part( 'template-parts/meet-team' );
		}
	}
}

if ( ! function_exists( 'csco_site_map' ) ) {
	/**
	 * Site Map
	 */
	function csco_site_map() {
		if ( is_page_template( 'template-site-map.php' ) ) {
			get_template_part( 'template-parts/site-map' );
		}
	}
}
