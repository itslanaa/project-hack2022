<?php
/**
 * Template Name: Site Map
 * Template Post Type: page
 *
 * @package Expertly
 */

__( 'Site Map', 'expertly' );

// Include default page template.
get_template_part( 'page' );
