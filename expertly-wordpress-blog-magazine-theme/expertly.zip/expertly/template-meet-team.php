<?php
/**
 * Template Name: Meet The Team
 * Template Post Type: page
 *
 * @package Expertly
 */

__( 'Meet The Team', 'expertly' );

// Include default page template.
get_template_part( 'page' );
